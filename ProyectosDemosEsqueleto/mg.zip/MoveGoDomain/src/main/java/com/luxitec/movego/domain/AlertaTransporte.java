package com.luxitec.movego.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "ALERTA_TRANSPORTE")
public class AlertaTransporte extends EntityDAO{

	private String titulo;
	private String mensaje;

	private boolean enviado;
	private Date fechaEnviado;
	private boolean recibido;
	private Date fechaRecibido;
		
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public boolean isEnviado() {
		return enviado;
	}
	public void setEnviado(boolean enviado) {
		this.enviado = enviado;
	}
	public Date getFechaEnviado() {
		return fechaEnviado;
	}
	public void setFechaEnviado(Date fechaEnviado) {
		this.fechaEnviado = fechaEnviado;
	}
	public boolean isRecibido() {
		return recibido;
	}
	public void setRecibido(boolean recibido) {
		this.recibido = recibido;
	}
	public Date getFechaRecibido() {
		return fechaRecibido;
	}
	public void setFechaRecibido(Date fechaRecibido) {
		this.fechaRecibido = fechaRecibido;
	}
	
	
	
	
}
