package com.luxitec.movego.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "Ruta")
public class Ruta extends EntityDAO {

	private Long idUsuarioSolicitante;
	private Long idLocalizacionSolicitante;

	private Long idUsuarioConductor;
	private Long idLocalizacionConductor;

	private String direccionConductor;

	private String direccion;
	private String referencia;
	private Long idLocalizacionDestino;

	// transent
	private Usuario usuarioSolicitante;
	private Localizacion localizacionSolicitante;
	private List<Localizacion> listaLocalizacionSolicitante;
	private Usuario usuarioConductor;
	private Localizacion localizacionConductor;
	private List<Localizacion> listaLocalizacionConductor;
	private Localizacion localizacionDestino;

	public Long getIdUsuarioSolicitante() {
		return idUsuarioSolicitante;
	}

	public void setIdUsuarioSolicitante(Long idUsuarioSolicitante) {
		this.idUsuarioSolicitante = idUsuarioSolicitante;
	}

	public Long getIdLocalizacionSolicitante() {
		return idLocalizacionSolicitante;
	}

	public void setIdLocalizacionSolicitante(Long idLocalizacionSolicitante) {
		this.idLocalizacionSolicitante = idLocalizacionSolicitante;
	}

	public Long getIdUsuarioConductor() {
		return idUsuarioConductor;
	}

	public void setIdUsuarioConductor(Long idUsuarioConductor) {
		this.idUsuarioConductor = idUsuarioConductor;
	}

	public Long getIdLocalizacionConductor() {
		return idLocalizacionConductor;
	}

	public void setIdLocalizacionConductor(Long idLocalizacionConductor) {
		this.idLocalizacionConductor = idLocalizacionConductor;
	}

	public String getDireccionConductor() {
		return direccionConductor;
	}

	public void setDireccionConductor(String direccionConductor) {
		this.direccionConductor = direccionConductor;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public Long getIdLocalizacionDestino() {
		return idLocalizacionDestino;
	}

	public void setIdLocalizacionDestino(Long idLocalizacionDestino) {
		this.idLocalizacionDestino = idLocalizacionDestino;
	}

	@Transient
	public Usuario getUsuarioSolicitante() {
		return usuarioSolicitante;
	}

	public void setUsuarioSolicitante(Usuario usuarioSolicitante) {
		this.usuarioSolicitante = usuarioSolicitante;
	}

	@Transient
	public Localizacion getLocalizacionSolicitante() {
		return localizacionSolicitante;
	}

	public void setLocalizacionSolicitante(Localizacion localizacionSolicitante) {
		this.localizacionSolicitante = localizacionSolicitante;
	}

	@Transient
	public List<Localizacion> getListaLocalizacionSolicitante() {
		return listaLocalizacionSolicitante;
	}

	public void setListaLocalizacionSolicitante(List<Localizacion> listaLocalizacionSolicitante) {
		this.listaLocalizacionSolicitante = listaLocalizacionSolicitante;
	}

	@Transient
	public Usuario getUsuarioConductor() {
		return usuarioConductor;
	}

	public void setUsuarioConductor(Usuario usuarioConductor) {
		this.usuarioConductor = usuarioConductor;
	}

	@Transient
	public Localizacion getLocalizacionConductor() {
		return localizacionConductor;
	}

	public void setLocalizacionConductor(Localizacion localizacionConductor) {
		this.localizacionConductor = localizacionConductor;
	}

	@Transient
	public List<Localizacion> getListaLocalizacionConductor() {
		return listaLocalizacionConductor;
	}

	public void setListaLocalizacionConductor(List<Localizacion> listaLocalizacionConductor) {
		this.listaLocalizacionConductor = listaLocalizacionConductor;
	}
	
	@Transient
	public Localizacion getLocalizacionDestino() {
		return localizacionDestino;
	}

	public void setLocalizacionDestino(Localizacion localizacionDestino) {
		this.localizacionDestino = localizacionDestino;
	}

}
