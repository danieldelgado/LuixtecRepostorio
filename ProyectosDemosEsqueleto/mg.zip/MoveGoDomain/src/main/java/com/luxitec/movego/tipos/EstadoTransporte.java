package com.luxitec.movego.tipos;

public enum EstadoTransporte {
	ESPERA("ESPERA"), TRANSCURSO("TRANSCURSO"), FINALIZADO("FINALIZADO"), INICIADO("INICIADO"), CANCELADO("CANCELADO"), PROBLEMAS_CONECTIVIDAD("PROBLEMAS_CONECTIVIDAD");

	private String estado;

	EstadoTransporte(String estado) {
		this.estado = estado;
	}

	public String getEstado() {
		return estado;
	}

}
