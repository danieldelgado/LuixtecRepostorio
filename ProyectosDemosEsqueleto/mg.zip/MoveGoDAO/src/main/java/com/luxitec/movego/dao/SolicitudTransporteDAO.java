package com.luxitec.movego.dao;

import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface SolicitudTransporteDAO extends IRepositoryDAO<SolicitudTransporte> {

	
}
