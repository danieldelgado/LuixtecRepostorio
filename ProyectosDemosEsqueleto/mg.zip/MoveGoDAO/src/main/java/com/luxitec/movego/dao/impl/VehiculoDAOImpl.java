package com.luxitec.movego.dao.impl;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.VehiculoDAO;
import com.luxitec.movego.domain.Vehiculo;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("VehiculoDAO")
public class VehiculoDAOImpl  extends RepositoryDAO<Vehiculo> implements VehiculoDAO {

}
