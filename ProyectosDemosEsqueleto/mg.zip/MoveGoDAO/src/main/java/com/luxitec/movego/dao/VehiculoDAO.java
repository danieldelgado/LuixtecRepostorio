package com.luxitec.movego.dao;

import com.luxitec.movego.domain.Vehiculo;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface VehiculoDAO  extends IRepositoryDAO<Vehiculo> {

}
