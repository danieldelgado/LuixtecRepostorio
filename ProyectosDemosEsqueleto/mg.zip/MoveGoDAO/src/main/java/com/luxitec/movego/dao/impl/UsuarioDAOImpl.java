package com.luxitec.movego.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.luxitec.movego.dao.UsuarioDAO;
import com.luxitec.movego.domain.Usuario;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Repository("UsuarioDAO")
@SuppressWarnings("unchecked")
public class UsuarioDAOImpl extends RepositoryDAO<Usuario> implements UsuarioDAO {

	@Override
	public Usuario getUsuarioForEmail(String email) throws MoveGoDAOException {

		final StringBuffer queryString = new StringBuffer("");
		queryString.append(" SELECT new Usuario( id,  nombre,  apellidoPaterno,  apellidoMaterno,  email) from Usuario u ");
		queryString.append(" where u.email= :email ");
		final Query query = this.em.createQuery(queryString.toString());
		query.setParameter("email", email);
		List<Usuario> lista = query.getResultList();
		if (!lista.isEmpty()) {
			return lista.get(0);
		}

		return null;
	}

	@Override
	public List<Usuario> getUsuarios(Usuario u) {
		final StringBuffer queryString = new StringBuffer("");
		queryString.append(" SELECT new Usuario( id,  nombre,  apellidoPaterno,  apellidoMaterno,  email) from Usuario u ");
		queryString.append(" where ");
		if (SimpleValidador.isNotClean(u.getEmail())) {
			queryString.append(" u.email like :email ");
		}
		if (SimpleValidador.isNotClean(u.getNombre())) {
			queryString.append(" u.nombre like :nombre ");
		}
		if (SimpleValidador.isNotClean(u.getApellidoPaterno())) {
			queryString.append(" u.apellidoPaterno like :apellidoPaterno ");
		}
		if (SimpleValidador.isNotClean(u.getNombre())) {
			queryString.append(" u.getApellidoMaterno like :apellidoMaterno ");
		}

		final Query query = this.em.createQuery(queryString.toString());
		if (SimpleValidador.isNotClean(u.getEmail())) {
			query.setParameter("email", "%" + u.getEmail() + "%");
		}
		if (SimpleValidador.isNotClean(u.getNombre())) {
			query.setParameter("nombre", "%" + u.getNombre() + "%");
		}
		if (SimpleValidador.isNotClean(u.getApellidoPaterno())) {
			query.setParameter("apellidoPaterno", "%" + u.getNombre() + "%");
		}

		if (SimpleValidador.isNotClean(u.getApellidoMaterno())) {
			query.setParameter("apellidoMaterno", "%" + u.getNombre() + "%");
		}

		List<Usuario> lista = query.getResultList();
		if (!lista.isEmpty()) {
			return lista;
		}
		return null;
	}

}
