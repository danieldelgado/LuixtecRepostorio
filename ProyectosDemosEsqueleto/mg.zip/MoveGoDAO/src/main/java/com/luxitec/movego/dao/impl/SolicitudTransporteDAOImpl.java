package com.luxitec.movego.dao.impl;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.SolicitudTransporteDAO;
import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("SolicitudTransporteDAO")
public class SolicitudTransporteDAOImpl extends RepositoryDAO<SolicitudTransporte> implements SolicitudTransporteDAO{

	
}
