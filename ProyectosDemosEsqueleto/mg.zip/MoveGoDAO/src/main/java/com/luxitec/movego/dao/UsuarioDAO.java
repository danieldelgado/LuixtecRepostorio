package com.luxitec.movego.dao;

import java.util.List;

import com.luxitec.movego.domain.Usuario;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface UsuarioDAO  extends IRepositoryDAO<Usuario> {

	Usuario getUsuarioForEmail(String email)throws MoveGoDAOException;

	List<Usuario> getUsuarios(Usuario u);


}
