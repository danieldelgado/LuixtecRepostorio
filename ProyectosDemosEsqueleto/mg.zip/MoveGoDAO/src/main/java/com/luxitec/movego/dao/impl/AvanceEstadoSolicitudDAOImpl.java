package com.luxitec.movego.dao.impl;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.AvanceEstadoSolicitudDAO;
import com.luxitec.movego.domain.AvanceEstadoSolicitud;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("AvanceEstadoSolicitudDAO")
public class AvanceEstadoSolicitudDAOImpl extends RepositoryDAO<AvanceEstadoSolicitud> implements AvanceEstadoSolicitudDAO{
	

}
