package com.luxitec.movego.dao.impl;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.ImagenDAO;
import com.luxitec.movego.domain.Imagen;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("ImagenDAO")
public class ImagenDAOImpl extends RepositoryDAO<Imagen> implements ImagenDAO {

	
	
}
