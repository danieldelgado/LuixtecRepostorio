package com.luxitec.movego.dao.impl;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.LocalizacionDAO;
import com.luxitec.movego.domain.Localizacion;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("LocalizacionDAO")
public class LocalizacionDAOImpl  extends RepositoryDAO<Localizacion> implements LocalizacionDAO{

	
		
}
