package com.luxitec.movego.dao;

import com.luxitec.movego.domain.AvanceEstadoSolicitud;
import com.luxitec.movego.util.repository.IRepositoryDAO;


public interface AvanceEstadoSolicitudDAO extends IRepositoryDAO<AvanceEstadoSolicitud>{
	

}
