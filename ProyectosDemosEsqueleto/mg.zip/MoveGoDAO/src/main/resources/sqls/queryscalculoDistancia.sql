
--http://www.tufuncion.com/distancia-coordenadas
SELECT (acos(sin(radians(36.720139)) * sin(radians(40.425797)) + 
cos(radians(36.720139)) * cos(radians(40.425797)) * 
cos(radians(-4.419422) - radians(-3.690462))) * 6378) as 
distanciaMalagaMadrid;

SELECT (acos(sin(radians(LATITUD_1)) * sin(radians(LATITUD_2)) + 
cos(radians(LATITUD_1)) * cos(radians(LATITUD_2)) * 
cos(radians(LONGITUD_1) - radians(LONGITUD_2))) * 6378) as 
distanciaPunto1Punto2;