package com.luxitec.movego.util.excepciones;

public class MoveGoDAOException extends MoveGoException {
	private static final long serialVersionUID = 1L;
	private int codigoError;
	private String errorMessage;


	public MoveGoDAOException(int codigoError,String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.codigoError = codigoError;
	}

	public MoveGoDAOException(int codigoError) {
		super(codigoError);
		this.codigoError = codigoError;
	}

	public int getCodigoError() {
		return codigoError;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public MoveGoDAOException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public MoveGoDAOException() {
		super();
	}
}
