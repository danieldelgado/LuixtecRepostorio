package com.luxitec.movego.util.repository;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.entidades.EntityDAO;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class RepositoryDAO<T extends EntityDAO> implements IRepositoryDAO<T> {

	private static final Logger LOG = LoggerFactory.getLogger(RepositoryDAO.class);

	public static final boolean HABILITADO_ACTIVO = true; 
	public static final boolean DESHABILITADO_ACTIVO = false; 
	
	@PersistenceContext
	protected EntityManager em;
	private Class<T> objeto;

	public RepositoryDAO() {
		Class obtainedClass = getClass();
		java.lang.reflect.Type genericSuperclass = null;
		for (;;) {
			genericSuperclass = obtainedClass.getGenericSuperclass();
			if (genericSuperclass instanceof ParameterizedType) {
				break;
			}
			obtainedClass = obtainedClass.getSuperclass();
		}
		ParameterizedType genericSuperclass_ = (ParameterizedType) genericSuperclass;
		objeto = ((Class) ((Class) genericSuperclass_.getActualTypeArguments()[0]));
	}

	public EntityManager getEntityManager() {
		return this.em;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.em = entityManager;
	}

	@Override
	@Transactional
	public void guardar(T o) throws MoveGoDAOException {
		LOG.debug("guardar :" + objeto);
		try {
			if (o.getId() == null) {
				this.em.persist(o);
			} else {
				this.em.merge(o);
			}
		} catch (Exception e) {
			LOG.error("Error en guardar", e);
			throw new MoveGoDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
	}

	@Override
	public T get(Long id) throws MoveGoDAOException {
		T r = null;
		try {
			r = this.em.find(objeto, id);
		} catch (Exception e) {
			LOG.error("Error en get", e);
			throw new MoveGoDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
		return r;
	}

	/**
	 * Habilita al objeto o deshabilita en el campo activo
	 */
	@Override
	public void habilitar(T obj, boolean activo) throws MoveGoDAOException {
		try {
			if (obj != null) {
				obj.setActivo(activo);
				guardar(obj);
			}
		} catch (Exception e) {
			LOG.error("Error en deleteActivo", e);
			throw new MoveGoDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
	}

	@Override
	public List<T> todo() throws MoveGoDAOException {
		LOG.debug("findAll :" + objeto);
		List<T> lista = null;
		try {
			final StringBuffer queryString = new StringBuffer("SELECT * from ");
			queryString.append(objeto.getSimpleName()).append(" o ");
			final Query query = this.em.createQuery(queryString.toString());
			lista = query.getResultList();
		} catch (Exception e) {
			LOG.error("Error en FindAll", e);
			throw new MoveGoDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
		return lista;
	}

}
