package com.luxitec.movego.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimpleValidador {

	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static final Pattern pattern = Pattern.compile(EMAIL_PATTERN);

	public static final boolean validateEmail(final String hex) {
		if(isClean(hex)){
			return false;
		}
		final Matcher matcher = pattern.matcher(hex);
		return matcher.matches();
	}

	public static final boolean isClean(final String o) {
		if(isNull(o)){
			return true;
		}
		return (o=="");
	}
	
	public static final boolean isNotClean(final String o) {
		return !isClean(o);
	}
	
	public static final boolean isNotNull(final Object o) {
		return !(isNull(o));
	}

	public static final boolean isNull(final Object o) {
		if (null == o) {
			return true;
		}
		return true;
	}
	
	private SimpleValidador() {
		
	}
	
}
