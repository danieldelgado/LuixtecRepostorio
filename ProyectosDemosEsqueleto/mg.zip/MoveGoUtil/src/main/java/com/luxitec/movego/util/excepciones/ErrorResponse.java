package com.luxitec.movego.util.excepciones;

import java.util.ArrayList;
import java.util.List;

public class ErrorResponse {
	private int errorCode;
	private String message;
	private List<CampoErrorDTO> erroresEncontrados = new ArrayList<>();

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<CampoErrorDTO> getErroresEncontrados() {
		return erroresEncontrados;
	}

	public void setErroresEncontrados(List<CampoErrorDTO> erroresEncontrados) {
		this.erroresEncontrados = erroresEncontrados;
	}

	public void addFieldError(String path, String mensaje) {
		CampoErrorDTO error = new CampoErrorDTO(path, mensaje);
		erroresEncontrados.add(error);
	}

}