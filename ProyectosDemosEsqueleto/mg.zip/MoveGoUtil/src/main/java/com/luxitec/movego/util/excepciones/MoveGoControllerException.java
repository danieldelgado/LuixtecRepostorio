package com.luxitec.movego.util.excepciones;

import org.springframework.validation.BindingResult;

public class MoveGoControllerException extends MoveGoServiceException {
	private static final long serialVersionUID = 1L;
	private int codigoError;
	private String errorMessage;
	private BindingResult bindingResult;

	public MoveGoControllerException(int codigoError,String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.codigoError = codigoError;
	}
	
	public MoveGoControllerException(int codigoError,String errorMessage, BindingResult bindingResult) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.codigoError = codigoError;
		this.bindingResult = bindingResult;
	}

	public int getCodigoError() {
		return codigoError;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public MoveGoControllerException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public MoveGoControllerException() {
		super();
	}

	public BindingResult getBindingResult() {
		return bindingResult;
	}

	public void setBindingResult(BindingResult bindingResult) {
		this.bindingResult = bindingResult;
	}

	public void setCodigoError(int codigoError) {
		this.codigoError = codigoError;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
