package com.luxitec.movego.usuario.controller.rest;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.service.UsuarioService;
import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@RestController
@RequestMapping("/usuario")
public class UsuarioRestController extends com.luxitec.movego.util.controller.RestController {

	@Autowired
	private UsuarioService usuarioService;

	@ResponseBody
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public UsuarioBean getUsuario(@PathVariable Long id) throws MoveGoControllerException {
		UsuarioBean u = null;
		try {
			u = new UsuarioBean();
			u.setId(id);
			u = usuarioService.get(u.getId());
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return u;
	}

	@ResponseBody
	@RequestMapping(value = "/email", method = RequestMethod.GET)
	public UsuarioBean getUsuarioByEmail(@RequestParam("email") String email) throws MoveGoControllerException {
		UsuarioBean u = null;
		try {
			u = usuarioService.getUsuarioForEmail(email);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return u;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public @ResponseBody List<UsuarioBean> getUsuarios(@RequestBody UsuarioBean usuario) throws MoveGoControllerException {
		List<UsuarioBean> lu = null;
		try {
			lu = usuarioService.getUsuarios(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return lu;
	}

	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public UsuarioBean registrarse(@RequestBody @Valid UsuarioBean usuario, BindingResult result) throws MoveGoControllerException {
		try {
			if (result.hasErrors()) {
				throw new MoveGoControllerException(ConstantesUtil.Errors.ERROR_ENTIDAD_VALIDAR, messageSource.getMessage(ConstantesUtil.Errors.MENSAJE_VALIDADCION_INCORRECTA, null, null), result);
			}
			usuarioService.guardar(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage(), result);
		}
		return usuario;
	}

	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.PUT)
	public UsuarioBean actualizar(@RequestBody UsuarioBean usuario) throws MoveGoControllerException {
		try {
			usuarioService.guardar(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return usuario;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public int eliminar(@PathVariable int id) throws MoveGoControllerException {
		UsuarioBean a = new UsuarioBean();
		a.setActivo(false);
		try {
			usuarioService.habilitar(a, UsuarioBean.IN_ACTIVO);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return ConstantesUtil.TRANSACCION_OK;
	}

}