package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.SolicitudTransporteBean;
import com.luxitec.movego.dao.SolicitudTransporteDAO;
import com.luxitec.movego.service.SolicitudTransporteService;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("SolicitudTransporteService")
public class SolicitudTransporteServiceImpl  implements SolicitudTransporteService{

	@Autowired
	private SolicitudTransporteDAO solicitudTransporteDAO;
	
	@Override
	public void registrarSolicitudTransporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {		
		
	}

	@Override
	public void guardar(SolicitudTransporteBean o) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SolicitudTransporteBean get(Long id) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void enviarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cancelarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void aceptaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void iniciarTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void finalizacionTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SolicitudTransporteBean getUltimaSolicitudTransporteBeanForUsuarioSolicitante(Long idUsuarioSolicitante)
			throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void habilitar(SolicitudTransporteBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<SolicitudTransporteBean> todo() throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
