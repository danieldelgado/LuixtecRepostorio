package com.luxitec.movego.service;

import com.luxitec.movego.bean.VehiculoBean;
import com.luxitec.movego.util.service.IService;

public interface VehiculoService extends IService<VehiculoBean> {

	VehiculoBean getVehiculo(Long idVehiculo);
	
}
