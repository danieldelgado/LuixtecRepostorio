package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.dao.LocalizacionDAO;
import com.luxitec.movego.service.LocalizacionService;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("LocalizacionService")
public class LocalizacionServiceImpl implements LocalizacionService {

	@Autowired
	private LocalizacionDAO localizacionDAO;
	
	
	@Override
	public double calcularDistanciaEntrePuntos(LocalizacionBean origen, LocalizacionBean destino)
			throws MoveGoServiceException {

		return 0;
	}

	@Override
	public List<LocalizacionBean> getLocalizacionCercanas(LocalizacionBean origen, int radioKm)
			throws MoveGoServiceException {

		return null;
	}

	@Override
	public void guardar(LocalizacionBean o) throws MoveGoServiceException {

	}

	@Override
	public LocalizacionBean get(Long id) throws MoveGoServiceException {

		return null;
	}

	@Override
	public long calcularTiempoEntrePuntos(LocalizacionBean origen, LocalizacionBean destino)
			throws MoveGoServiceException {

		return 0;
	}

	@Override
	public List<LocalizacionBean> getListaTrayectoria(Long idUsuario, boolean transcurso)
			throws MoveGoServiceException {

		return null;
	}

	@Override
	public LocalizacionBean getUltimaUbicacion(Long idUsuario) throws MoveGoServiceException {

		return null;
	}

	@Override
	public void habilitar(LocalizacionBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<LocalizacionBean> todo() throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

}
