package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.AvanceEstadoSolicitudBean;
import com.luxitec.movego.dao.AvanceEstadoSolicitudDAO;
import com.luxitec.movego.domain.AvanceEstadoSolicitud;
import com.luxitec.movego.service.AvanceEstadoSolicitudService;
import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("AvanceEstadoSolicitudService")
public class AvanceEstadoSolicitudServiceImpl implements AvanceEstadoSolicitudService {

	private static final Logger LOG = LoggerFactory.getLogger(AvanceEstadoSolicitudServiceImpl.class);
	@Autowired
	private AvanceEstadoSolicitudDAO avanceEstadoSolicitudDAO;

	@Override
	public void guardar(AvanceEstadoSolicitudBean o) throws MoveGoServiceException {
		AvanceEstadoSolicitud avanceEstadoSolicitud = new AvanceEstadoSolicitud();
		try {
			avanceEstadoSolicitudDAO.guardar(avanceEstadoSolicitud);
			Trasnfer.copyFields(o, avanceEstadoSolicitud);
		} catch (MoveGoDAOException e) {
			throw new MoveGoServiceException(3, "Error al guardar el avance de estado");
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
	}

	@Override
	public AvanceEstadoSolicitudBean get(Long id) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registrarAvanceEstado(Long idSolicitud, EstadoTransporte estado) throws MoveGoServiceException {
		// TODO Auto-generated method stub

	}

	@Override
	public void habilitar(AvanceEstadoSolicitudBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<AvanceEstadoSolicitudBean> todo() throws MoveGoServiceException {
		List<AvanceEstadoSolicitud> lista = null;
		try {
			lista = avanceEstadoSolicitudDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<AvanceEstadoSolicitudBean> lretunr = new ArrayList<>();
		AvanceEstadoSolicitudBean bre = null;
		try {
			for (AvanceEstadoSolicitud avanceEstadoSolicitud : lista) {
				Trasnfer.copyFields(avanceEstadoSolicitud, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

		return lretunr;
	}

}
