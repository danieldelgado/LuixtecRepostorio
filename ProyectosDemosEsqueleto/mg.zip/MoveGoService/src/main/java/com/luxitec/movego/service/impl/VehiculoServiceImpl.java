package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.VehiculoBean;
import com.luxitec.movego.dao.VehiculoDAO;
import com.luxitec.movego.service.VehiculoService;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("VehiculoService")
public class VehiculoServiceImpl implements VehiculoService {

	@Autowired
	private VehiculoDAO vehiculoDAO;
	
	
	@Override
	public void guardar(VehiculoBean o) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public VehiculoBean get(Long id) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VehiculoBean getVehiculo(Long idVehiculo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void habilitar(VehiculoBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<VehiculoBean> todo() throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

}
