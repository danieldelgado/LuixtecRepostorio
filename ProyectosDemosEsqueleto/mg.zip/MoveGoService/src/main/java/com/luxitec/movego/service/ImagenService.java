package com.luxitec.movego.service;

import com.luxitec.movego.bean.ImagenBean;
import com.luxitec.movego.tipos.TipoImagen;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface ImagenService extends IService<ImagenBean>{

	ImagenBean getImagen(TipoImagen tipoImagen, Long id) throws MoveGoServiceException;
	ImagenBean getImagenVehiculo(Long idVehiculo) throws MoveGoServiceException;
	ImagenBean getImagenUsuario(Long idUsuario) throws MoveGoServiceException;
	
	
}
