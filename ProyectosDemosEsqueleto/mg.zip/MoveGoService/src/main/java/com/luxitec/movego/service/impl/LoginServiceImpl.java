package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.service.LoginService;
import com.luxitec.movego.service.UsuarioService;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("LoginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private UsuarioService usuarioService;

	@Override
	public UsuarioBean getUsuarioForEmail(String email) throws MoveGoServiceException {
		UsuarioBean a = new UsuarioBean();
		usuarioService.getUsuarioForEmail(email);
		return a;
	}

	@Override
	public UsuarioBean getIniciarSession(String email, String password) throws MoveGoServiceException {
		UsuarioBean a = new UsuarioBean();
		usuarioService.getUsuarioForEmail(email);

		return a;
	}

	@Override
	public UsuarioBean registrarse(UsuarioBean usuario) throws MoveGoServiceException {
		usuarioService.guardar(usuario);
		return usuario;
	}

	@Override
	public void guardar(UsuarioBean o) throws MoveGoServiceException {

	}

	@Override
	public UsuarioBean get(Long id) throws MoveGoServiceException {

		return null;
	}

	@Override
	public void habilitar(UsuarioBean obj, boolean activo) throws MoveGoServiceException {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<UsuarioBean> todo() throws MoveGoServiceException {		
		throw new UnsupportedOperationException();
	}

}
