package com.luxitec.movego.service;

import java.util.List;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface LocalizacionService extends IService<LocalizacionBean>{

	double calcularDistanciaEntrePuntos( LocalizacionBean origen,LocalizacionBean destino ) throws MoveGoServiceException;
	long calcularTiempoEntrePuntos( LocalizacionBean origen,LocalizacionBean destino ) throws MoveGoServiceException;//calcula en milisegundos
	List<LocalizacionBean> getLocalizacionCercanas(LocalizacionBean origen, int radioKm ) throws MoveGoServiceException;
		
	List<LocalizacionBean> getListaTrayectoria(Long idUsuario, boolean transcurso) throws MoveGoServiceException;
	LocalizacionBean getUltimaUbicacion(Long idUsuario) throws MoveGoServiceException;
		
}
