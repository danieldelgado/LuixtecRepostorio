package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.ImagenBean;
import com.luxitec.movego.dao.ImagenDAO;
import com.luxitec.movego.service.ImagenService;
import com.luxitec.movego.tipos.TipoImagen;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("ImagenService")
public class ImagenServiceImpl implements ImagenService {

	@Autowired
	private ImagenDAO imagenDAO;
	
	@Override
	public void guardar(ImagenBean o) throws MoveGoServiceException {
		
		
	}

	@Override
	public ImagenBean get(Long id) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void habilitar(ImagenBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ImagenBean> todo() throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ImagenBean getImagen(TipoImagen tipoImagen, Long id) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ImagenBean getImagenVehiculo(Long idVehiculo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ImagenBean getImagenUsuario(Long idUsuario) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

//	@Autowired
//	private Imagen
	
	
	

}
