package com.luxitec.movego.bean;

import com.luxitec.movego.util.entidades.EntityBean;

public class VehiculoBean extends EntityBean {
	
	private String marca;
	private String modelo;
	private String placa;
	private String soat;
	private Long idUsuario;
	
	private UsuarioBean usuarioConductor;

	private Long idImagen;
	
	private ImagenBean imagenVehiculo;

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getSoat() {
		return soat;
	}

	public void setSoat(String soat) {
		this.soat = soat;
	}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public UsuarioBean getUsuarioConductor() {
		return usuarioConductor;
	}

	public void setUsuarioConductor(UsuarioBean usuarioConductor) {
		this.usuarioConductor = usuarioConductor;
	}

	public Long getIdImagen() {
		return idImagen;
	}

	public void setIdImagen(Long idImagen) {
		this.idImagen = idImagen;
	}

	public ImagenBean getImagenVehiculo() {
		return imagenVehiculo;
	}

	public void setImagenVehiculo(ImagenBean imagenVehiculo) {
		this.imagenVehiculo = imagenVehiculo;
	}

	
	
	
}
