package com.luxitec.movego.controller.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;

@RestController
@RequestMapping("/localizacion")
public class LoginRestController {


	@RequestMapping(value = "/person", method = RequestMethod.GET)
	public LocalizacionBean getPersonDetail(@RequestParam(value = "id", required = false, defaultValue = "0") Integer id) throws MoveGoControllerException {

		return null;
	}
	
	
//	@RequestMapping(value = "/person", method = RequestMethod.GET)
//	public UsuarioBean getPersonDetail(@RequestParam(value = "id", required = false, defaultValue = "0") Integer id) throws MoveGoControllerException {
//
////		if (id == 0) {
////            throw new MoveGoAdapterException(678,"The 'name' parameter must not be null or empty");
////        }
////		
////		UsuarioBean p = personService.getPersonDetail(id);
//		return null;
//	}
//	
}