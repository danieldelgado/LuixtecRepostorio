package com.luxitec.movego.config;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class MoveGoRestLocalizacionApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(MoveGoRestLocalizacionApplication.class, args);
//	}
//}
