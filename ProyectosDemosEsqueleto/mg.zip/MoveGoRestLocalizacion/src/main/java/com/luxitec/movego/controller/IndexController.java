package com.luxitec.movego.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.luxitec.movego.util.Util;

@Controller
@RequestMapping("/")
public class IndexController {

	@RequestMapping(method = RequestMethod.GET)
	public String getIndexPage() {
		Util a = new Util();
//		Usuario a = new Usuario();
//		
		System.out.println(a);
		
		return "index";
	}

}