package com.spring.jsf.primefaces.manageBean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;
import org.primefaces.model.chart.PieChartModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.service.PrincipalService;
import com.spring.jsf.primefaces.util.BusinessGeneralManageBean;
import com.spring.jsf.primefaces.util.Util;

//https://cdcvs.fnal.gov/redmine/projects/fess/wiki/Sentinel
//http://www.primefaces.org/sentinel/dashboard.xhtml

@SuppressWarnings("serial")
@Component
@ManagedBean
@ViewScoped
public class PrincipalManageBean extends BusinessGeneralManageBean implements Serializable {
	private Log log = LogFactory.getLog(PrincipalManageBean.class);
	private String email;
	private String usuario;
	private String contrasenna;
	@Inject
	private AuthenticationManager authenticationManager;

	@Autowired
	private PrincipalService principalService;
	
	private DashboardModel model;
	private LineChartModel lineModel;
	private PieChartModel pieModel;

	@PostConstruct
	public void init() {
		log.info("Init PrincipalManageBean");
		super.initBean();
		System.out.println(usuarioService);
	}

	public void setLineModel(LineChartModel lineModel) {
		this.lineModel = lineModel;
	}

	public void setPieModel(PieChartModel pieModel) {
		this.pieModel = pieModel;
	}

	@Override
	public void inicioPagina() {
		log.info("inicioPagina -- Cargando DashBoard ...");

		model = new DefaultDashboardModel();
		DashboardColumn column1 = new DefaultDashboardColumn();
		DashboardColumn column2 = new DefaultDashboardColumn();
		DashboardColumn column3 = new DefaultDashboardColumn();

		column1.addWidget("sports");
		column1.addWidget("finance");

		column2.addWidget("lifestyle");
		column2.addWidget("weather");

		column3.addWidget("politics");

		model.addColumn(column1);
		model.addColumn(column2);
		model.addColumn(column3);

		initLinearModel();
		initPieModel();

	}


	private void initLinearModel() {
		lineModel = new LineChartModel();
		lineModel.setTitle("Linear Chart");
		lineModel.setLegendPosition("e");
		lineModel.setExtender("skinChart");
		lineModel.setAnimate(true);
		Axis yAxis = lineModel.getAxis(AxisType.Y);
		yAxis.setMin(0);
		yAxis.setMax(10);

		LineChartSeries series1 = new LineChartSeries();
		series1.setLabel("Series 1");

		series1.set(1, 2);
		series1.set(2, 1);
		series1.set(3, 3);
		series1.set(4, 6);
		series1.set(5, 8);

		LineChartSeries series2 = new LineChartSeries();
		series2.setLabel("Series 2");

		series2.set(1, 6);
		series2.set(2, 3);
		series2.set(3, 2);
		series2.set(4, 7);
		series2.set(5, 9);

		lineModel.addSeries(series1);
		lineModel.addSeries(series2);
	}

	private void initPieModel() {
		pieModel = new PieChartModel();
		pieModel.set("Brand 1", 540);
		pieModel.set("Brand 2", 325);
		pieModel.set("Brand 3", 702);
		pieModel.set("Brand 4", 421);
		pieModel.setExtender("skinPie");
	}

	
	public String iniciarSession() {
		try {
			Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(this.usuario, this.contrasenna));
			SecurityContextHolder.getContext().setAuthentication(authentication);
			UsuarioBean u = new UsuarioBean();
			u.setEmial(usuario);
			u.setPassword(contrasenna);

			Util.addSession("usuarioSession", u);
			Util.addSession("menuSession", principalService.listaMenuOpciones(u));

		} catch (AuthenticationException ex) {
			Util.addMessageError("Credenciales Incorrectas", "Login Failed: " + ex.getMessage());
			return "";
		}
		return Util.getSavedUrl() + "?faces-redirect=true";
	}

	public String inicio() {
		return "login";
	}
	

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasenna() {
		return contrasenna;
	}

	public void setContrasenna(String contrasenna) {
		this.contrasenna = contrasenna;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public DashboardModel getModel() {
		return model;
	}

	public void setModel(DashboardModel model) {
		this.model = model;
	}

	public LineChartModel getLineModel() {
		return lineModel;
	}

	public PieChartModel getPieModel() {
		return pieModel;
	}

	

}
