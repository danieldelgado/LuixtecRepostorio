package com.spring.jsf.primefaces.service;

public interface PermisoService {

	
}
