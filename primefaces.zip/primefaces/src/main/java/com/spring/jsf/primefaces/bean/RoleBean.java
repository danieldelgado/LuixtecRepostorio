package com.spring.jsf.primefaces.bean;

import java.io.Serializable;

import com.spring.jsf.primefaces.util.ModeloBean;

@SuppressWarnings("serial")
public class RoleBean extends ModeloBean  implements Serializable{

	private long id;
	private String role;
	private String descripcion;

	private boolean activo;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
}
