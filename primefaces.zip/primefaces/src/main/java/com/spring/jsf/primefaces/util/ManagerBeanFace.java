package com.spring.jsf.primefaces.util;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.jsf.primefaces.service.UsuarioService;

public abstract class ManagerBeanFace  extends BusinessGeneralManageBean{

	@Autowired
	public UsuarioService usuarioService;

	public abstract void listar();
	
	public abstract String irNuevo();
	public abstract String irActualizar();
	public abstract void desactivar();
	public abstract void guardar();
	
	public abstract String cancelar();	

}
