package com.spring.jsf.primefaces.dao;

public interface MenuDAO {

}
