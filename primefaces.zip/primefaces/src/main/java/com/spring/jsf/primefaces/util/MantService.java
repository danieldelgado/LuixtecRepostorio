package com.spring.jsf.primefaces.util;

import java.util.List;

public abstract class MantService< T extends ModeloBean> extends BusinessGeneralService {
	
	public abstract List<T> listar(T obj);
	
	public abstract int desactivar();

	public abstract int nuevo();

	public abstract int actualizar();
	
	public abstract T get(long id);
	
	
}
