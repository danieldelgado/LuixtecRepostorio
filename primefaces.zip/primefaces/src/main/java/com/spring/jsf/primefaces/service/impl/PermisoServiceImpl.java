package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.PermisoBean;
import com.spring.jsf.primefaces.dao.PermisoDAO;
import com.spring.jsf.primefaces.service.PermisoService;
import com.spring.jsf.primefaces.util.MantService;

@Service("PermisoService")
public class PermisoServiceImpl  extends MantService<PermisoBean> implements PermisoService {
	private Log LOG = LogFactory.getLog(PermisoServiceImpl.class);

	@Autowired
	private PermisoDAO permisoDAO;
	
	@Override
	public List<PermisoBean> listar(PermisoBean obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int desactivar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int nuevo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int actualizar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PermisoBean get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
