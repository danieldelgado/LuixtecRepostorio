package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.spring.jsf.primefaces.util.Entity;

@SuppressWarnings("serial")
public class Menu extends Entity implements Serializable {

	private String opcionMenu;
	private String url;
	private String icono;	
	private boolean permitido;	
	private Menu menuPadre;
	
	private List<Menu> subMenus;
	
	public Menu() {
	}

	public Menu(Long id) {
		super(id);
	}

	public Menu(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String opcionMenu, String url, String icono, boolean permitido, Menu menuPadre, List<Menu> subMenus) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.opcionMenu = opcionMenu;
		this.url = url;
		this.icono = icono;
		this.permitido = permitido;
		this.menuPadre = menuPadre;
		this.subMenus = subMenus;
	}


	public Menu(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String opcionMenu, String url, String icono, boolean permitido) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.opcionMenu = opcionMenu;
		this.url = url;
		this.icono = icono;
		this.permitido = permitido;
	}



	public Menu(String opcionMenu, String url, String icono, boolean permitido, Menu menuPadre, List<Menu> subMenus) {
		super();
		this.opcionMenu = opcionMenu;
		this.url = url;
		this.icono = icono;
		this.permitido = permitido;
		this.menuPadre = menuPadre;
		this.subMenus = subMenus;
	}
	public String getOpcionMenu() {
		return opcionMenu;
	}
	public void setOpcionMenu(String opcionMenu) {
		this.opcionMenu = opcionMenu;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getIcono() {
		return icono;
	}
	public void setIcono(String icono) {
		this.icono = icono;
	}
	public boolean isPermitido() {
		return permitido;
	}
	public void setPermitido(boolean permitido) {
		this.permitido = permitido;
	}

	public List<Menu> getSubMenus() {
		return subMenus;
	}
	public void setSubMenus(List<Menu> subMenus) {
		this.subMenus = subMenus;
	}	
	public Menu getMenuPadre() {
		return menuPadre;
	}
	public void setMenuPadre(Menu menuPadre) {
		this.menuPadre = menuPadre;
	}
	
	
	
}
