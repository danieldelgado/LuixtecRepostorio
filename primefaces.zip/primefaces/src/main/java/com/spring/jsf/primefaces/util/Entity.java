package com.spring.jsf.primefaces.util;

import java.util.Date;

public class Entity {

	private Long id;
	private String codigo;

	private boolean activo;
	private Long idUsuarioCrea;
	private Date fechaCrea;
	private Long idUsuarioActualiza;
	private Date fechaActualiza;
		
	public Entity() {
	}

	public Entity(Long id) {
		super();
		this.id = id;
	}
	
	public Entity( String codigo) {
		super();
		this.codigo = codigo;
	}
	
	public Entity(Long id, String codigo, boolean activo) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.activo = activo;
	}
	
	public Entity(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.activo = activo;
		this.idUsuarioCrea = idUsuarioCrea;
		this.fechaCrea = fechaCrea;
		this.idUsuarioActualiza = idUsuarioActualiza;
		this.fechaActualiza = fechaActualiza;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Long getIdUsuarioCrea() {
		return idUsuarioCrea;
	}
	public void setIdUsuarioCrea(Long idUsuarioCrea) {
		this.idUsuarioCrea = idUsuarioCrea;
	}
	public Date getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(Date fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public Long getIdUsuarioActualiza() {
		return idUsuarioActualiza;
	}
	public void setIdUsuarioActualiza(Long idUsuarioActualiza) {
		this.idUsuarioActualiza = idUsuarioActualiza;
	}
	public Date getFechaActualiza() {
		return fechaActualiza;
	}
	public void setFechaActualiza(Date fechaActualiza) {
		this.fechaActualiza = fechaActualiza;
	}
	
	
	
	
}
