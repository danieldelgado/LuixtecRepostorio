package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.RolDAO;

@Repository("RolDAO")
public class RolDAOImpl implements RolDAO {
	private Log LOG = LogFactory.getLog(RolDAOImpl.class);

}
