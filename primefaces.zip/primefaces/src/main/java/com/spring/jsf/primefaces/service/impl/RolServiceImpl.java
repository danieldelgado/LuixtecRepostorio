package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.RoleBean;
import com.spring.jsf.primefaces.dao.RolDAO;
import com.spring.jsf.primefaces.service.RolService;
import com.spring.jsf.primefaces.util.MantService;

@Service("RolService")
public class RolServiceImpl extends MantService<RoleBean>  implements RolService {
	private Log LOG = LogFactory.getLog(RolServiceImpl.class);


	@Autowired
	private RolDAO rolDAO;
	
	@Override
	public List<RoleBean> listar(RoleBean obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int desactivar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int nuevo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int actualizar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RoleBean get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
