package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;

import com.spring.jsf.primefaces.util.Entity;

@SuppressWarnings("serial")
public class Permiso  extends Entity implements Serializable{
	
	public final static long  TIPO_MENU = 1000;	
	public final static long  TIPO_BUTTON = 1200 ;
	
	private long tipoPermiso;
	private String objeto;
	private boolean permitido;
	
	
	public Permiso() {
	}
	
	public Permiso(Long id) {
		super(id);
	}
		
	public Permiso(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, long tipoPermiso, String objeto, boolean permitido) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.tipoPermiso = tipoPermiso;
		this.objeto = objeto;
		this.permitido = permitido;
	}
	
	public long getTipoPermiso() {
		return tipoPermiso;
	}
	public void setTipoPermiso(long tipoPermiso) {
		this.tipoPermiso = tipoPermiso;
	}
	public String getObjeto() {
		return objeto;
	}
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}
	public boolean isPermitido() {
		return permitido;
	}
	public void setPermitido(boolean permitido) {
		this.permitido = permitido;
	}
	
}
