package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.MenuDAO;

@Repository("MenuDAO")
public class MenuDAOImpl implements MenuDAO {
	private Log LOG = LogFactory.getLog(MenuDAOImpl.class);

}
