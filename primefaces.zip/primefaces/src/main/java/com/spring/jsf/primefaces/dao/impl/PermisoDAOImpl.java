package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.PermisoDAO;

@Repository("PermisoDAO")
public class PermisoDAOImpl implements PermisoDAO {
	private Log LOG = LogFactory.getLog(PermisoDAOImpl.class);

}
