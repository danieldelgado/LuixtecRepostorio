package com.spring.jsf.primefaces.bean;

import java.io.Serializable;
import java.util.List;

import com.spring.jsf.primefaces.util.ModeloBean;

@SuppressWarnings("serial")
public class MenuBean extends ModeloBean implements Serializable {

	private long id;
	private String codigo;
	private String opcionMenu;
	private String url;
	private String icono;	
	private boolean permitido;	
	private MenuBean menuBeanPadre;
	
	private List<MenuBean> subMenus;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getOpcionMenu() {
		return opcionMenu;
	}
	public void setOpcionMenu(String opcionMenu) {
		this.opcionMenu = opcionMenu;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getIcono() {
		return icono;
	}
	public void setIcono(String icono) {
		this.icono = icono;
	}
	public boolean isPermitido() {
		return permitido;
	}
	public void setPermitido(boolean permitido) {
		this.permitido = permitido;
	}
	public MenuBean getMenuBeanPadre() {
		return menuBeanPadre;
	}
	public void setMenuBeanPadre(MenuBean menuBeanPadre) {
		this.menuBeanPadre = menuBeanPadre;
	}
	public List<MenuBean> getSubMenus() {
		return subMenus;
	}
	public void setSubMenus(List<MenuBean> subMenus) {
		this.subMenus = subMenus;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	
	
}
