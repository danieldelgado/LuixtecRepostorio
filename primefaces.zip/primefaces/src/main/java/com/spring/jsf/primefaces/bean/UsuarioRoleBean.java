package com.spring.jsf.primefaces.bean;

import java.io.Serializable;

import com.spring.jsf.primefaces.util.ModeloBean;

@SuppressWarnings("serial")
public class UsuarioRoleBean extends ModeloBean implements Serializable {

	private long idUsuario;
	private long idRol;
	
	private UsuarioBean usuarioBean;
	private RoleBean roleBean;
	
	private boolean activo;

	public long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public long getIdRol() {
		return idRol;
	}

	public void setIdRol(long idRol) {
		this.idRol = idRol;
	}

	public UsuarioBean getUsuarioBean() {
		return usuarioBean;
	}

	public void setUsuarioBean(UsuarioBean usuarioBean) {
		this.usuarioBean = usuarioBean;
	}

	public RoleBean getRoleBean() {
		return roleBean;
	}

	public void setRoleBean(RoleBean roleBean) {
		this.roleBean = roleBean;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
	
	
}
