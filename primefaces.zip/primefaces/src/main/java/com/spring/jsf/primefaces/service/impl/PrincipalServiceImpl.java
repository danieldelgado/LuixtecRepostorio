package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.service.MenuService;
import com.spring.jsf.primefaces.service.PrincipalService;
import com.spring.jsf.primefaces.util.BusinessGeneralService;

@Service("PrincipalService")
public class PrincipalServiceImpl extends BusinessGeneralService  implements PrincipalService {
	private Log LOG = LogFactory.getLog(PermisoServiceImpl.class);

	@Autowired
	private MenuService menuService;

	@Override
	public List<MenuBean> listaMenuOpciones(UsuarioBean usuarioSession) {
		LOG.info("listaMenuOpciones");		
		return menuService.listaOpciones(usuarioSession);
	}
	
}
