package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;

import com.spring.jsf.primefaces.util.Entity;

@SuppressWarnings("serial")
public class Role extends Entity  implements Serializable{

	private String role;
	private String descripcion;

	public Role(Long id) {
		super(id);
	}

	public Role(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String role, String descripcion) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.role = role;
		this.descripcion = descripcion;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
