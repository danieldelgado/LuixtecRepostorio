package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.UsuarioDAO;

@Repository("UsuarioDAO")
public class UsuarioDAOImpl implements UsuarioDAO {
	private Log LOG = LogFactory.getLog(UsuarioDAOImpl.class);

}
