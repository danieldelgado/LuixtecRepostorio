package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.dao.UsuarioDAO;
import com.spring.jsf.primefaces.service.UsuarioService;
import com.spring.jsf.primefaces.util.MantService;

@Service("UsuarioService")
public class UsuarioServiceImpl extends MantService<UsuarioBean>  implements UsuarioService {
	private Log LOG = LogFactory.getLog(UsuarioServiceImpl.class);

	
	@Autowired
	private UsuarioDAO usuarioDAO;
	
	@Override
	public List<UsuarioBean> listar(UsuarioBean obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int desactivar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int nuevo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int actualizar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public UsuarioBean get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
