package com.spring.jsf.primefaces.manageBean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.spring.jsf.primefaces.util.ManagerBeanFace;

//https://cdcvs.fnal.gov/redmine/projects/fess/wiki/Sentinel
//http://www.primefaces.org/sentinel/dashboard.xhtml

@SuppressWarnings("serial")
@Component
@ManagedBean
@ViewScoped
public class MantRolMBean extends ManagerBeanFace implements Serializable {
	private Log log = LogFactory.getLog(MantRolMBean.class);

	@PostConstruct
	public void init() {
		log.info("Init MantRolMBean");
		super.initBean();
	}


	@Override
	public void inicioPagina() {
		
	}


	@Override
	public void listar() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public String irNuevo() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String irActualizar() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void desactivar() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void guardar() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public String cancelar() {
		// TODO Auto-generated method stub
		return null;
	}


}
