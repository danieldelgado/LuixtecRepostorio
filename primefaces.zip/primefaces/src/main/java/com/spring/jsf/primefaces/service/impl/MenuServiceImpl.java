package com.spring.jsf.primefaces.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.dao.MenuDAO;
import com.spring.jsf.primefaces.service.MenuService;
import com.spring.jsf.primefaces.util.MantService;

@Service("MenuService")
public class MenuServiceImpl extends MantService<MenuBean> implements MenuService {
	private Log LOG = LogFactory.getLog(MenuServiceImpl.class);

	@Autowired
	private MenuDAO menuDAO;
	
	@Override
	public List<MenuBean> listaOpciones(UsuarioBean usuarioSession) {
		List<MenuBean> opcionGenerales = new ArrayList<MenuBean>();
		{
			MenuBean opcionGeneral = new MenuBean();
			opcionGeneral.setId(1);
			opcionGeneral.setOpcionMenu("DashBoard");
			opcionGeneral.setPermitido(true);
			opcionGeneral.setUrl("/admin/principal");
			opcionGeneral.setIcono("icon-table");
			opcionGenerales.add(opcionGeneral);
		}
		{
			MenuBean opcionMantenimiento = new MenuBean();
			opcionMantenimiento.setId(2);
			opcionMantenimiento.setOpcionMenu("Mantenimientos");
			opcionMantenimiento.setPermitido(true);
			opcionMantenimiento.setIcono("icon-table");
			opcionGenerales.add(opcionMantenimiento);

			List<MenuBean> opcionesSubMantenimiento = new ArrayList<MenuBean>();
			{
				MenuBean opcionAdministrarUsuario = new MenuBean();
				opcionAdministrarUsuario.setId(3);
				opcionAdministrarUsuario.setOpcionMenu("Mantenimiento Usuario");
				opcionAdministrarUsuario.setPermitido(true);
				opcionAdministrarUsuario.setUrl("/admin/mantenimiento/usuario/usuarios");
//				opcionAdministrarUsuario.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarUsuario.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarUsuario);
			}
			{
				MenuBean opcionAdministrarRole = new MenuBean();
				opcionAdministrarRole.setId(4);
				opcionAdministrarRole.setOpcionMenu("Mantenimiento Roles");
				opcionAdministrarRole.setPermitido(true);
				opcionAdministrarRole.setUrl("/admin/mantenimiento/rol/roles");
//				opcionAdministrarRole.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarRole.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarRole);
			}
			{
				MenuBean opcionAdministrarPermisos = new MenuBean();
				opcionAdministrarPermisos.setId(5);
				opcionAdministrarPermisos.setOpcionMenu("Mantenimiento Permisos");
				opcionAdministrarPermisos.setPermitido(true);
				opcionAdministrarPermisos.setUrl("/admin/mantenimiento/permiso/permisos");
//				opcionAdministrarPermisos.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarPermisos.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarPermisos);
			}
			{
				MenuBean opcionAdministrarPermisos = new MenuBean();
				opcionAdministrarPermisos.setId(6);
				opcionAdministrarPermisos.setOpcionMenu("Mantenimiento Menu");
				opcionAdministrarPermisos.setPermitido(true);
				opcionAdministrarPermisos.setUrl("/admin/mantenimiento/menu/menus");
				opcionAdministrarPermisos.setIcono("icon-table");
//				opcionAdministrarPermisos.setMenuBeanPadre(opcionMantenimiento);
				opcionesSubMantenimiento.add(opcionAdministrarPermisos);
			}
			opcionMantenimiento.setSubMenus(opcionesSubMantenimiento);
		}
		return opcionGenerales;
	}

	@Override
	public List<MenuBean> listar(MenuBean obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int desactivar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int nuevo() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int actualizar() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public MenuBean get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
