package com.spring.jsf.primefaces.bean;

import java.io.Serializable;

import com.spring.jsf.primefaces.util.ModeloBean;

@SuppressWarnings("serial")
public class PermisoBean  extends ModeloBean implements Serializable{
	
	public final static long  TIPO_MENU = 1000;	
	public final static long  TIPO_BUTTON = 1200 ;
	
	private long id;
	private long tipoPermiso;
	private String objeto;
	private boolean permitido;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getTipoPermiso() {
		return tipoPermiso;
	}
	public void setTipoPermiso(long tipoPermiso) {
		this.tipoPermiso = tipoPermiso;
	}
	public String getObjeto() {
		return objeto;
	}
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}
	public boolean isPermitido() {
		return permitido;
	}
	public void setPermitido(boolean permitido) {
		this.permitido = permitido;
	}
	
}
