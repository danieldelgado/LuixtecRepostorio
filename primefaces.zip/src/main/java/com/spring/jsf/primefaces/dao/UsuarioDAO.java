package com.spring.jsf.primefaces.dao;

import com.spring.jsf.primefaces.entitys.Usuario;
import com.spring.jsf.primefaces.util.IRepositoryDAO;

public interface UsuarioDAO  extends IRepositoryDAO<Usuario>{

}
