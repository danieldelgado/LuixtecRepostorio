package com.spring.jsf.primefaces.util;

import java.net.URL;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;

public class Util {

	static Log log = LogFactory.getLog(Util.class);

	public static void addMessage(String msg) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(msg));
	}
	
	public static void addMessageInfo(String titulo, String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, titulo, msg));
    }
	public static void addMessageInfo(String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg));
    }

    public static void addMessageWarn(String titulo, String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, titulo, msg));
    }

    public static void addMessageWarn(String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, msg, msg));
    }

    public static void addMessageError(String titulo, String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, titulo, msg));
    }
    public static void addMessageError( String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg));
    }
    
    public static void addMessageFatal(String titulo, String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, titulo, msg));
    }
    
    public static void addMessageFatal( String msg) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, msg, msg));
    }

	public static String getParameter(String param) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		if (request != null) {
			return request.getParameter(param);
		}
		return null;
	}

	public static String getSavedUrl() {
		HttpServletRequest request = ((HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest());

		SavedRequest savedRequest = new HttpSessionRequestCache().getRequest(request, (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse());

		if (savedRequest != null) {
			try {
				URL url = new URL(savedRequest.getRedirectUrl());
				return url.getFile().substring(request.getContextPath().length());
			} catch (Exception e) {
				log.error(e.getMessage() + " Using default URL");
			}
		}
		return "admin/principal.xhtml?faces-redirect=true";
	}
	
	public static void addSession(String name, Object obj){		
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		Map<String, Object> sessionMap = externalContext.getSessionMap();
		sessionMap.put(name, obj);		
	}
	
	public static Object getObjectSession(String name){
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		Map<String, Object> sessionMap = externalContext.getSessionMap();
		return sessionMap.get(name);		
	}
	
}
