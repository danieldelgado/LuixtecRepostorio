package com.spring.jsf.primefaces.dao.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.bean.PermisoBean;
import com.spring.jsf.primefaces.dao.PermisoDAO;
import com.spring.jsf.primefaces.entitys.Permiso;
import com.spring.jsf.primefaces.util.RepositoryDAO;
import com.spring.jsf.primefaces.util.SystemDAOException;

@Repository("PermisoDAO")
public class PermisoDAOImpl extends RepositoryDAO<Permiso> implements PermisoDAO {
	private Log LOG = LogFactory.getLog(PermisoDAOImpl.class);

	@Override
	public List<Permiso> listar(PermisoBean obj) throws SystemDAOException {
		LOG.info("listar");
		return null;
	}

}
