package com.spring.jsf.primefaces.util;

import java.util.List;

public interface IRepositoryDAO<T extends EntityClass> {
		
	void guardar(T o) throws SystemDAOException;
	T get(Long id)  throws SystemDAOException;
	void habilitar(T obj, boolean activo) throws SystemDAOException;
	List<T> todo() throws SystemDAOException;

}
