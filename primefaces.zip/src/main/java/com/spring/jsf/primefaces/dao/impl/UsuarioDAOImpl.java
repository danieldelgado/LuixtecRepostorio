package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.UsuarioDAO;
import com.spring.jsf.primefaces.entitys.Usuario;
import com.spring.jsf.primefaces.util.RepositoryDAO;

@Repository("UsuarioDAO")
public class UsuarioDAOImpl extends RepositoryDAO<Usuario> implements UsuarioDAO {
	private Log LOG = LogFactory.getLog(UsuarioDAOImpl.class);

}
