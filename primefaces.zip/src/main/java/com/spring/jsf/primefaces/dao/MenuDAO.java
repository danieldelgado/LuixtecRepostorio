package com.spring.jsf.primefaces.dao;

import java.util.List;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.entitys.Menu;
import com.spring.jsf.primefaces.util.IRepositoryDAO;
import com.spring.jsf.primefaces.util.SystemDAOException;

public interface MenuDAO extends IRepositoryDAO<Menu> {

	List<Menu> listar(MenuBean obj) throws SystemDAOException;

}
