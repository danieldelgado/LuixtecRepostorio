package com.spring.jsf.primefaces.util;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class EntityClass {

	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name="codigo")
	private String codigo;

	@Column(name="activo")
	private boolean activo;
	
	@Column(name="idUsuarioCrea")
	private Long idUsuarioCrea;
	
	@Column(name="fechaCrea")
	private Date fechaCrea;
	
	@Column(name="idUsuarioActualiza")
	private Long idUsuarioActualiza;
	
	@Column(name="fechaActualiza")
	private Date fechaActualiza;
		
	public EntityClass() {
	}

	public EntityClass(Long id) {
		super();
		this.id = id;
	}
	
	public EntityClass( String codigo) {
		super();
		this.codigo = codigo;
	}
	
	public EntityClass(Long id, String codigo, boolean activo) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.activo = activo;
	}
	
	public EntityClass(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.activo = activo;
		this.idUsuarioCrea = idUsuarioCrea;
		this.fechaCrea = fechaCrea;
		this.idUsuarioActualiza = idUsuarioActualiza;
		this.fechaActualiza = fechaActualiza;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Long getIdUsuarioCrea() {
		return idUsuarioCrea;
	}
	public void setIdUsuarioCrea(Long idUsuarioCrea) {
		this.idUsuarioCrea = idUsuarioCrea;
	}
	public Date getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(Date fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public Long getIdUsuarioActualiza() {
		return idUsuarioActualiza;
	}
	public void setIdUsuarioActualiza(Long idUsuarioActualiza) {
		this.idUsuarioActualiza = idUsuarioActualiza;
	}
	public Date getFechaActualiza() {
		return fechaActualiza;
	}
	public void setFechaActualiza(Date fechaActualiza) {
		this.fechaActualiza = fechaActualiza;
	}
	
	
	
	
}
