package com.spring.jsf.primefaces.service;

import java.util.List;

import com.spring.jsf.primefaces.bean.PermisoBean;
import com.spring.jsf.primefaces.util.ServiceSystem;
import com.spring.jsf.primefaces.util.SystemServiceException;

public interface PermisoService  extends ServiceSystem<PermisoBean> {

	public List<PermisoBean> listar(PermisoBean obj) throws SystemServiceException;
	
}
