package com.spring.jsf.primefaces.manageBean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.util.ManagerBeanFace;

//https://cdcvs.fnal.gov/redmine/projects/fess/wiki/Sentinel
//http://www.primefaces.org/sentinel/dashboard.xhtml

@SuppressWarnings("serial")
@Component
@ManagedBean
@ViewScoped
public class MantMenuMBean extends ManagerBeanFace implements Serializable {
	private Log log = LogFactory.getLog(MantMenuMBean.class);

	private MenuBean menuBean;
	private List<MenuBean> listMenuBean;

	@PostConstruct
	public void init() {
		log.info("Init MantMenuMBean");
		super.initBean();
	}

	@Override
	public void inicioPagina() {
		menuBean = new MenuBean();
		listMenuBean = new ArrayList<MenuBean>();
	}


	@Override
	public String cancelar() {
		return "/admin/mantenimiento/menu/menus";
	}

	@Override
	public String irNuevo() {
		return "/admin/mantenimiento/menu/actualizarMenu";
	}

	@Override
	public String irActualizar() {
		return "/admin/mantenimiento/menu/actualizarMenu";
	}

	@Override
	public void desactivar() {
		
	}

	@Override
	public void guardar() {
		
	}
	
	
	
	public MenuBean getMenuBean() {
		return menuBean;
	}

	public void setMenuBean(MenuBean menuBean) {
		this.menuBean = menuBean;
	}

	public List<MenuBean> getListMenuBean() {
		return listMenuBean;
	}

	public void setListMenuBean(List<MenuBean> listMenuBean) {
		this.listMenuBean = listMenuBean;
	}

	@Override
	public void listar() {
		// TODO Auto-generated method stub
		
	}

	


}
