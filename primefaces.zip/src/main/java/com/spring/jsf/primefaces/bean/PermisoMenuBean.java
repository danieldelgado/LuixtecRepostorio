package com.spring.jsf.primefaces.bean;

import java.io.Serializable;

import com.spring.jsf.primefaces.util.ModeloBean;

@SuppressWarnings("serial")
public class PermisoMenuBean  extends ModeloBean implements Serializable{

	private PermisoBean permisoBean;
	private MenuBean menuBean;
	public PermisoBean getPermisoBean() {
		return permisoBean;
	}
	public void setPermisoBean(PermisoBean permisoBean) {
		this.permisoBean = permisoBean;
	}
	public MenuBean getMenuBean() {
		return menuBean;
	}
	public void setMenuBean(MenuBean menuBean) {
		this.menuBean = menuBean;
	}
	
	
	
}
