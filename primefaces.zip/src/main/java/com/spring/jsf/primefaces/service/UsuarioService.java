package com.spring.jsf.primefaces.service;

import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.util.ServiceSystem;

public interface UsuarioService  extends ServiceSystem<UsuarioBean> {

	
}
