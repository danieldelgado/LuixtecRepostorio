package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity 
@Table(name="MENU")
public class Menu extends EntityClass implements Serializable {

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "recursoId", unique = true, nullable = true, insertable = true, updatable = true)
	private Recurso recurso;
	
	@Column(name="opcionMenu")
	private String opcionMenu;
	@Column(name="url")
	private String url;
	@Column(name="icono")
	private String icono;	
	
	@ManyToOne 
	@JoinColumn(name="menuP")
	private Menu menuPadre;
	
	@OneToMany(mappedBy="menuPadre")
	private List<Menu> subMenus;
	
	public Menu() {
	}

	public Menu(Long id) {
		super(id);
	}

	public String getOpcionMenu() {
		return opcionMenu;
	}

	public void setOpcionMenu(String opcionMenu) {
		this.opcionMenu = opcionMenu;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getIcono() {
		return icono;
	}

	public void setIcono(String icono) {
		this.icono = icono;
	}

	public Menu getMenuPadre() {
		return menuPadre;
	}

	public void setMenuPadre(Menu menuPadre) {
		this.menuPadre = menuPadre;
	}

	public List<Menu> getSubMenus() {
		return subMenus;
	}

	public void setSubMenus(List<Menu> subMenus) {
		this.subMenus = subMenus;
	}

	public Recurso getRecurso() {
		return recurso;
	}

	public void setRecurso(Recurso recurso) {
		this.recurso = recurso;
	}

	
	
	
}
