package com.spring.jsf.primefaces.service;

import java.util.List;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.util.ServiceSystem;

public interface MenuService extends ServiceSystem<MenuBean>{

	public List<MenuBean> listaOpciones(UsuarioBean usuarioSession);
	
	
}
