package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.dao.UsuarioDAO;
import com.spring.jsf.primefaces.service.UsuarioService;
import com.spring.jsf.primefaces.util.MantService;
import com.spring.jsf.primefaces.util.SystemServiceException;

@Service("UsuarioService")
public class UsuarioServiceImpl extends MantService<UsuarioBean>  implements UsuarioService {
	private Log LOG = LogFactory.getLog(UsuarioServiceImpl.class);

	
	@Autowired
	private UsuarioDAO usuarioDAO;


	@Override
	public List<UsuarioBean> listar(UsuarioBean obj) throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<UsuarioBean> todo() throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void guardar(UsuarioBean o) throws SystemServiceException {
		// TODO Auto-generated method stub
		
	}


	@Override
	public UsuarioBean get(Long id) throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void habilitar(UsuarioBean obj, boolean activo) throws SystemServiceException {
		// TODO Auto-generated method stub
		
	}
	

	
}
