package com.spring.jsf.primefaces.util;

@SuppressWarnings("serial")
public class SystemServiceException extends Exception {

	public SystemServiceException() {
		super();
	}

	public SystemServiceException(String errorConexionBaseDatos) {
		super(errorConexionBaseDatos);
	}

	public SystemServiceException(int transformarError) {
		
	}

}
