package com.spring.jsf.primefaces.util;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.jsf.primefaces.service.UsuarioService;

public abstract class BusinessGeneralManageBean {

	@Autowired
	public UsuarioService usuarioService;

	public void initBean() {

	}
	
	public abstract void inicioPagina();



}
