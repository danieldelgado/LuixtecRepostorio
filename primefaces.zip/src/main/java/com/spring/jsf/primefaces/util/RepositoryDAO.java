package com.spring.jsf.primefaces.util;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class RepositoryDAO<T extends EntityClass> implements IRepositoryDAO<T> {

	private static final Logger LOG = LoggerFactory.getLogger(RepositoryDAO.class);

	public static String SQL_WHERE = " where ";
	public static String SQL_AND = " and ";
	public static String SQL_PORCENT = "%";
	public static final boolean HABILITADO_ACTIVO = true; 
	public static final boolean DESHABILITADO_ACTIVO = false; 
	
	@PersistenceContext
	protected EntityManager em;
	private Class<T> objeto;

	public RepositoryDAO() {
		Class obtainedClass = getClass();
		java.lang.reflect.Type genericSuperclass = null;
		for (;;) {
			genericSuperclass = obtainedClass.getGenericSuperclass();
			if (genericSuperclass instanceof ParameterizedType) {
				break;
			}
			obtainedClass = obtainedClass.getSuperclass();
		}
		ParameterizedType genericSuperclass_ = (ParameterizedType) genericSuperclass;
		objeto = ((Class) ((Class) genericSuperclass_.getActualTypeArguments()[0]));
	}

	public EntityManager getEntityManager() {
		return this.em;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.em = entityManager;
	}

	@Override
	@Transactional
	public void guardar(T o) throws SystemDAOException {
		LOG.debug("guardar :" + objeto);
		try {
			if (o.getId() == null) {
				this.em.persist(o);
			} else {
				this.em.merge(o);
			}
		} catch (Exception e) {
			LOG.error("Error en guardar", e);
			throw new SystemDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
	}

	@Override
	public T get(Long id) throws SystemDAOException {
		T r = null;
		try {
			r = this.em.find(objeto, id);
		} catch (Exception e) {
			LOG.error("Error en get", e);
			throw new SystemDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
		return r;
	}

	/**
	 * Habilita al objeto o deshabilita en el campo activo
	 */
	@Override
	public void habilitar(T obj, boolean activo) throws SystemDAOException {
		try {
			if (obj != null) {
				obj.setActivo(activo);
				guardar(obj);
			}
		} catch (Exception e) {
			LOG.error("Error en deleteActivo", e);
			throw new SystemDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
	}

	@Override
	public List<T> todo() throws SystemDAOException {
		LOG.debug("findAll :" + objeto);
		List<T> lista = null;
		try {
			final StringBuffer queryString = new StringBuffer("SELECT * from ");
			queryString.append(objeto.getSimpleName()).append(" o ");
			final Query query = this.em.createQuery(queryString.toString());
			lista = query.getResultList();
		} catch (Exception e) {
			LOG.error("Error en FindAll", e);
			throw new SystemDAOException(ConstantesUtil.Errors.ERROR_CONEXION_BASE_DATOS);
		}
		return lista;
	}

	public boolean establecerCondicion(StringBuffer sbQuery, String condicion, Object param) {
		if (sbQuery.toString().indexOf(SQL_WHERE) == -1 && SimpleValidador.isNotNull(param)) {
			sbQuery.append(SQL_WHERE);
		}
		if (SimpleValidador.isNotNull(param)) {
			sbQuery.append(condicion);
			sbQuery.append(SQL_AND);
			return true;
		} else
			return false;
	}
	
	public boolean establecerCondicionIN(StringBuffer sbQuery, String condicion, List<?> param) {
		if (sbQuery.toString().indexOf(SQL_WHERE) == -1 && SimpleValidador.isNotNull(param)) {
			sbQuery.append(SQL_WHERE);
		}
		if (param != null && !param.isEmpty()) {
			sbQuery.append(condicion);
			sbQuery.append(SQL_AND);
			return true;
		} else
			return false;
	}

	public void establecerParam(Query query, String nombCampo, Object param) {
		establecerParam(query, nombCampo, param, false, false);
	}

	public void establecerParamIN(Query query, String nombCampo, List<?> param) {
		if (param != null && !param.isEmpty()) {
			query.setParameter(nombCampo, param);
		}
	}

	public void establecerParam(Query query, String nombCampo, Object param, boolean esLike, boolean convertirMayuscula) {
		if (SimpleValidador.isNotNull(param)) {
			if (esLike) {
				query.setParameter(nombCampo, SQL_PORCENT + (convertirMayuscula ? param.toString().toUpperCase() : param) + SQL_PORCENT);
			} else {
				query.setParameter(nombCampo, param);
			}
		}
	}
	
	
	
	

}
