package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity 
@Table(name="USUARIO")
public class Usuario  extends EntityClass implements Serializable {

	@Column(name="nombre")
	private String nombre;
	@Column(name="apellidoPaterno")
	private String apellidoPaterno;
	@Column(name="apellidoMaterno")
	private String apellidoMaterno;

	@Column(name="emial")
	private String emial;
	@Column(name="password")
	private String password;

	@JoinTable(name="usuario_roles" , joinColumns=@JoinColumn(name="usuarioId"),
	          inverseJoinColumns=@JoinColumn(name="roleId"))
	@ManyToMany
	private List<Role> roles;
	
	public Usuario(){
		
	}
	public Usuario(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String nombre, String apellidoPaterno, String apellidoMaterno, String emial, String password) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.emial = emial;
		this.password = password;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public String getEmial() {
		return emial;
	}

	public void setEmial(String emial) {
		this.emial = emial;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
