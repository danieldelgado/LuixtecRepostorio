package com.spring.jsf.primefaces.util;

import java.util.List;

public abstract class MantService< T extends ModeloBean> extends BusinessGeneralService{
	
	public abstract List<T> listar(T obj)throws SystemServiceException;
	public abstract List<T> todo() throws SystemServiceException;	
	public abstract void guardar(T o) throws SystemServiceException;	
	public abstract T get(Long id)  throws SystemServiceException;	
	public abstract void habilitar(T obj, boolean activo) throws SystemServiceException;
	
	
	
}
