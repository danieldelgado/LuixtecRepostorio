package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity 
@Table(name="Recurso")
public class Recurso extends EntityClass implements Serializable {

	public final static long TIPO_MENU = 1;
	public final static long TIPO_COMPONENTE = 2; 
	
	@Column(name="descripcion")
	private String descripcion;
	
	@Column(name="tipoRecurso")
	private long tipoRecurso;

	public Recurso(){
	}
	
	public Recurso(Long id) {
		super(id);
	}

	public Recurso(Long id, String descripcion) {
		super(id);
		this.descripcion = descripcion;
	}
	
	public Recurso(Long id, String descripcion, long tipoRecurso) {
		super(id);
		this.descripcion = descripcion;
		this.tipoRecurso = tipoRecurso;
	}
	
	public Recurso(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String descripcion) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.descripcion = descripcion;
	}

	public Recurso(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getTipoRecurso() {
		return tipoRecurso;
	}

	public void setTipoRecurso(long tipoRecurso) {
		this.tipoRecurso = tipoRecurso;
	}

	
}
