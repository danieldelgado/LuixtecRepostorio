package com.spring.jsf.primefaces.dao;

import com.spring.jsf.primefaces.entitys.Role;
import com.spring.jsf.primefaces.util.IRepositoryDAO;

public interface RolDAO  extends IRepositoryDAO<Role>{

}
