package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity
@Table(name = "Componente")
public class Componente extends EntityClass implements Serializable {

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "recursoId", unique = true, nullable = true, insertable = true, updatable = true)
	private Recurso recurso;

	@Column(name = "icono")
	private String icono;

	@Column(name = "accion")
	private String accion;

	@Column(name = "funcion")
	private String funcion;

	public Componente() {
	}

	public Componente(Long id) {
		super(id);
	}

	public String getIcono() {
		return icono;
	}

	public void setIcono(String icono) {
		this.icono = icono;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getFuncion() {
		return funcion;
	}

	public void setFuncion(String funcion) {
		this.funcion = funcion;
	}

	public Recurso getRecurso() {
		return recurso;
	}

	public void setRecurso(Recurso recurso) {
		this.recurso = recurso;
	}

}
