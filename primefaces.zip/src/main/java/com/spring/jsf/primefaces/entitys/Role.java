package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity 
@Table(name="ROLE")
public class Role extends EntityClass  implements Serializable{

	@Column(name="role")
	private String role;
	@Column(name="descripcion")
	private String descripcion;

    @ManyToMany(mappedBy="roles")
    private List<Usuario> usuarios;
    
    
    @JoinTable(name="rol_permisos" , joinColumns=@JoinColumn(name="roleId"),
	          inverseJoinColumns=@JoinColumn(name="permisoId"))
	@ManyToMany
	private List<Permiso> permisos;
    
	public Role() {
	}
	
	public Role(Long id) {
		super(id);
	}

	public Role(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, String role, String descripcion) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.role = role;
		this.descripcion = descripcion;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
