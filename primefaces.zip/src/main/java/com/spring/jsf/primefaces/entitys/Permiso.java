package com.spring.jsf.primefaces.entitys;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.spring.jsf.primefaces.util.EntityClass;

@SuppressWarnings("serial")
@Entity 
@Table(name="Permiso")
public class Permiso  extends EntityClass implements Serializable{
	
	public final static long  TIPO_MENU = 1000;	
	public final static long  TIPO_BUTTON = 1200 ;

	@Column(name="tipoPermiso")
	private long tipoPermiso;
	@Column(name="objeto")
	private String objeto;
	@Column(name="permitido")
	private boolean permitido;
	

    @ManyToMany(mappedBy="permisos")
    private List<Role> roles;
       

    @JoinTable(name="permiso_recurso" , joinColumns=@JoinColumn(name="permisoId"),
	          inverseJoinColumns=@JoinColumn(name="recursoId"))
	@ManyToMany
	private List<Recurso> recursos;
    
	public Permiso() {
	}
	
	public Permiso(Long id) {
		super(id);
	}
		
	public Permiso(Long id, String codigo, boolean activo, Long idUsuarioCrea, Date fechaCrea, Long idUsuarioActualiza, Date fechaActualiza, long tipoPermiso, String objeto, boolean permitido) {
		super(id, codigo, activo, idUsuarioCrea, fechaCrea, idUsuarioActualiza, fechaActualiza);
		this.tipoPermiso = tipoPermiso;
		this.objeto = objeto;
		this.permitido = permitido;
	}
	
	public long getTipoPermiso() {
		return tipoPermiso;
	}
	public void setTipoPermiso(long tipoPermiso) {
		this.tipoPermiso = tipoPermiso;
	}
	public String getObjeto() {
		return objeto;
	}
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}
	public boolean isPermitido() {
		return permitido;
	}
	public void setPermitido(boolean permitido) {
		this.permitido = permitido;
	}

	public List<Recurso> getRecursos() {
		return recursos;
	}

	public void setRecursos(List<Recurso> recursos) {
		this.recursos = recursos;
	}
	
}
