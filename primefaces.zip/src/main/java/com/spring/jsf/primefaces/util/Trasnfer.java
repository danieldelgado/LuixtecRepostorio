package com.spring.jsf.primefaces.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Trasnfer {
	private static final Logger LOG = LoggerFactory.getLogger(Trasnfer.class);

	public static <T extends Object, Y extends Object> void copyFields(T from, Y too) throws SystemServiceException {
		if (from == null) {
			throw new NullPointerException("EL objeto base es null");
		}
		if (too == null) {
			throw new NullPointerException("EL objeto destino es null");
		}
		try {
			Class<? extends Object> fromClass = from.getClass();
			Method[] fromMethos = fromClass.getMethods();
			Map<String, Method> mapMethodFrom = new LinkedHashMap<>();
			for (Method method : fromMethos) {
				if ((method.getName().indexOf("get") > -1)) {
					mapMethodFrom.put(method.getName(), method);
				}
			}
			Class<? extends Object> tooClass = too.getClass();
			Method[] tooMethos = tooClass.getMethods();
			Map<String, Method> mapMethodTo = new LinkedHashMap<>();
			for (Method method : tooMethos) {
				if ((method.getName().indexOf("set") > -1)) {
					mapMethodTo.put(method.getName(), method);
				}
			}
			for (String key : mapMethodFrom.keySet()) {
				Object val;
				val = mapMethodFrom.get(key).invoke(from, new Class[] {});

				key = key.replaceAll("get", "set");
				if ((key.equals("getClass")) || (key.equals("setClass"))) {
					continue;
				}
				if (mapMethodTo.get(key) != null) {
					mapMethodTo.get(key).invoke(too, val);
				} else {
					LOG.error("Campo no encontrado en el objeto destino:" + key);
				}

			}

		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			throw new SystemServiceException(ConstantesUtil.Errors.TRANSFORMAR_ERROR);
		}

	}
}
