package com.spring.jsf.primefaces.service;

import com.spring.jsf.primefaces.bean.RoleBean;
import com.spring.jsf.primefaces.util.ServiceSystem;

public interface RolService extends ServiceSystem<RoleBean> {

	
}
