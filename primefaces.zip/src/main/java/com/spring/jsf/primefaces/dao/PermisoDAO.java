package com.spring.jsf.primefaces.dao;

import java.util.List;

import com.spring.jsf.primefaces.bean.PermisoBean;
import com.spring.jsf.primefaces.entitys.Permiso;
import com.spring.jsf.primefaces.util.IRepositoryDAO;
import com.spring.jsf.primefaces.util.SystemDAOException;

public interface PermisoDAO  extends IRepositoryDAO<Permiso>{

	List<Permiso> listar(PermisoBean obj)throws SystemDAOException;

}
