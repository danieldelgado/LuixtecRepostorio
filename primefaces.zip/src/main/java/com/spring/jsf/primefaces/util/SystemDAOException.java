package com.spring.jsf.primefaces.util;

@SuppressWarnings("serial")
public class SystemDAOException extends Exception {

	public SystemDAOException() {
		super();
	}

	public SystemDAOException(String errorConexionBaseDatos) {
		super(errorConexionBaseDatos);
	}

}
