package com.spring.jsf.primefaces.util;

public abstract class BusinessGeneralService {

}
