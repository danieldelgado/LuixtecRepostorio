package com.spring.jsf.primefaces.service;

import java.util.List;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.bean.UsuarioBean;

public interface PrincipalService {

	public List<MenuBean> listaMenuOpciones(UsuarioBean usuarioSession);
	
}
