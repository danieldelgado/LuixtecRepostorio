package com.spring.jsf.primefaces.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.bean.UsuarioBean;
import com.spring.jsf.primefaces.dao.MenuDAO;
import com.spring.jsf.primefaces.entitys.Menu;
import com.spring.jsf.primefaces.service.MenuService;
import com.spring.jsf.primefaces.util.MantService;
import com.spring.jsf.primefaces.util.SystemDAOException;
import com.spring.jsf.primefaces.util.SystemServiceException;
import com.spring.jsf.primefaces.util.Trasnfer;

@Service("MenuService")
public class MenuServiceImpl extends MantService<MenuBean> implements MenuService {
	private Log LOG = LogFactory.getLog(MenuServiceImpl.class);

	@Autowired
	private MenuDAO menuDAO;
	
	@Override
	public List<MenuBean> listaOpciones(UsuarioBean usuarioSession) {
		List<MenuBean> opcionGenerales = new ArrayList<MenuBean>();
		{
			MenuBean opcionGeneral = new MenuBean();
			opcionGeneral.setId(1);
			opcionGeneral.setOpcionMenu("DashBoard");
			opcionGeneral.setPermitido(true);
			opcionGeneral.setUrl("/admin/principal");
			opcionGeneral.setIcono("icon-table");
			opcionGenerales.add(opcionGeneral);
		}
		{
			MenuBean opcionMantenimiento = new MenuBean();
			opcionMantenimiento.setId(2);
			opcionMantenimiento.setOpcionMenu("Mantenimientos");
			opcionMantenimiento.setPermitido(true);
			opcionMantenimiento.setIcono("icon-table");
			opcionGenerales.add(opcionMantenimiento);

			List<MenuBean> opcionesSubMantenimiento = new ArrayList<MenuBean>();
			{
				MenuBean opcionAdministrarUsuario = new MenuBean();
				opcionAdministrarUsuario.setId(3);
				opcionAdministrarUsuario.setOpcionMenu("Mantenimiento Usuario");
				opcionAdministrarUsuario.setPermitido(true);
				opcionAdministrarUsuario.setUrl("/admin/mantenimiento/usuario/usuarios");
//				opcionAdministrarUsuario.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarUsuario.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarUsuario);
			}
			{
				MenuBean opcionAdministrarRole = new MenuBean();
				opcionAdministrarRole.setId(4);
				opcionAdministrarRole.setOpcionMenu("Mantenimiento Roles");
				opcionAdministrarRole.setPermitido(true);
				opcionAdministrarRole.setUrl("/admin/mantenimiento/rol/roles");
//				opcionAdministrarRole.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarRole.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarRole);
			}
			{
				MenuBean opcionAdministrarPermisos = new MenuBean();
				opcionAdministrarPermisos.setId(5);
				opcionAdministrarPermisos.setOpcionMenu("Mantenimiento Permisos");
				opcionAdministrarPermisos.setPermitido(true);
				opcionAdministrarPermisos.setUrl("/admin/mantenimiento/permiso/permisos");
//				opcionAdministrarPermisos.setMenuBeanPadre(opcionMantenimiento);
				opcionAdministrarPermisos.setIcono("icon-table");
				opcionesSubMantenimiento.add(opcionAdministrarPermisos);
			}
			{
				MenuBean opcionAdministrarPermisos = new MenuBean();
				opcionAdministrarPermisos.setId(6);
				opcionAdministrarPermisos.setOpcionMenu("Mantenimiento Menu");
				opcionAdministrarPermisos.setPermitido(true);
				opcionAdministrarPermisos.setUrl("/admin/mantenimiento/menu/menus");
				opcionAdministrarPermisos.setIcono("icon-table");
//				opcionAdministrarPermisos.setMenuBeanPadre(opcionMantenimiento);
				opcionesSubMantenimiento.add(opcionAdministrarPermisos);
			}
			opcionMantenimiento.setSubMenus(opcionesSubMantenimiento);
		}
		return opcionGenerales;
	}

	@Override
	public List<MenuBean> listar(MenuBean obj) throws SystemServiceException {	
		LOG.info("listar");
		List<MenuBean>  l =  new ArrayList<>();
		try {
			List<Menu> m = menuDAO.listar(obj);
			MenuBean mb = null;
			for (Menu menu : m) {
				mb = new MenuBean();
				Trasnfer.copyFields(menu, mb);
				l.add(mb);
			}
		} catch (SystemDAOException e) {
			LOG.error("Error en listar",e);
			throw new SystemServiceException();
		}		
		return l;
	}

	@Override
	public List<MenuBean> todo() throws SystemServiceException {
		LOG.info("todo");
		List<MenuBean>  l =  new ArrayList<>();
		try {
			List<Menu> m =  menuDAO.todo();
			MenuBean mb = null;
			for (Menu menu : m) {
				mb = new MenuBean();
				Trasnfer.copyFields(menu, mb);
				l.add(mb);
			}			
		} catch (SystemDAOException e) {
			LOG.error("Error en todo",e);
			throw new SystemServiceException();			
		}		
		return l;
	}

	@Transactional
	@Override
	public void guardar(MenuBean o) throws SystemServiceException {
		LOG.info("guardar");		
		try {
			Menu m =  new Menu();
			Trasnfer.copyFields(o, m);
			menuDAO.guardar(m);			
		} catch (SystemDAOException e) {
			LOG.error("Error en guardar",e);
			throw new SystemServiceException();	
		}
	}

	@Override
	public MenuBean get(Long id) throws SystemServiceException {
		LOG.info("get");
		MenuBean menu = new MenuBean();
		try {
			Menu m =  menuDAO.get(id);			
			Trasnfer.copyFields(m, menu);			
		} catch (SystemDAOException e) {
			LOG.error("Error en get",e);
			throw new SystemServiceException();	
		}
		return menu;
	}

	@Override
	public void habilitar(MenuBean obj, boolean activo) throws SystemServiceException {
		LOG.info("habilitar");		
		try {
			Menu m =  menuDAO.get(obj.getId());			
			menuDAO.habilitar(m, activo);			
		} catch (SystemDAOException e) {
			LOG.error("Error en habilitar",e);
			throw new SystemServiceException();	
		}
	}

	

}
