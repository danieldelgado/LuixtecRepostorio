package com.spring.jsf.primefaces.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.PermisoBean;
import com.spring.jsf.primefaces.dao.PermisoDAO;
import com.spring.jsf.primefaces.entitys.Permiso;
import com.spring.jsf.primefaces.service.PermisoService;
import com.spring.jsf.primefaces.util.MantService;
import com.spring.jsf.primefaces.util.SystemDAOException;
import com.spring.jsf.primefaces.util.SystemServiceException;
import com.spring.jsf.primefaces.util.Trasnfer;

@Service("PermisoService")
public class PermisoServiceImpl  extends MantService<PermisoBean> implements PermisoService {
	private Log LOG = LogFactory.getLog(PermisoServiceImpl.class);

	@Autowired
	private PermisoDAO permisoDAO;
	
	@Override
	public List<PermisoBean> listar(PermisoBean obj) throws SystemServiceException{
		LOG.info("listar");
		List<PermisoBean>  l =  new ArrayList<>();
		try {
			List<Permiso> m = permisoDAO.listar(obj);
			PermisoBean mb = null;
			for (Permiso menu : m) {
				mb = new PermisoBean();
				Trasnfer.copyFields(menu, mb);
				l.add(mb);
			}
		} catch (SystemDAOException e) {
			LOG.error("Error en listar",e);
			throw new SystemServiceException();
		}		
		return l;
	}

	@Override
	public List<PermisoBean> todo() throws SystemServiceException {
		LOG.info("listar");
		List<PermisoBean>  l =  new ArrayList<>();
		try {
			List<Permiso> m = permisoDAO.todo();
			PermisoBean mb = null;
			for (Permiso menu : m) {
				mb = new PermisoBean();
				Trasnfer.copyFields(menu, mb);
				l.add(mb);
			}
		} catch (SystemDAOException e) {
			LOG.error("Error en listar",e);
			throw new SystemServiceException();
		}		
		return l;
	}

	@Override
	public void guardar(PermisoBean o) throws SystemServiceException {
		LOG.info("guardar");		
		try {
			Permiso m =  new Permiso();
			Trasnfer.copyFields(o, m);
			permisoDAO.guardar(m);			
		} catch (SystemDAOException e) {
			LOG.error("Error en guardar",e);
			throw new SystemServiceException();	
		}
	}

	@Override
	public PermisoBean get(Long id) throws SystemServiceException {
		LOG.info("get");
		PermisoBean menu = new PermisoBean();
		try {
			Permiso m =  permisoDAO.get(id);			
			Trasnfer.copyFields(m, menu);			
		} catch (SystemDAOException e) {
			LOG.error("Error en get",e);
			throw new SystemServiceException();	
		}
		return menu;
	}

	@Override
	public void habilitar(PermisoBean obj, boolean activo) throws SystemServiceException {
		LOG.info("habilitar");		
		try {
			Permiso m =  permisoDAO.get(obj.getId());			
			permisoDAO.habilitar(m, activo);			
		} catch (SystemDAOException e) {
			LOG.error("Error en habilitar",e);
			throw new SystemServiceException();	
		}
	}


	
}
