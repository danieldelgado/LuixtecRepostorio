package com.spring.jsf.primefaces.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.jsf.primefaces.bean.RoleBean;
import com.spring.jsf.primefaces.dao.RolDAO;
import com.spring.jsf.primefaces.service.RolService;
import com.spring.jsf.primefaces.util.MantService;
import com.spring.jsf.primefaces.util.SystemServiceException;

@Service("RolService")
public class RolServiceImpl extends MantService<RoleBean>  implements RolService {
	private Log LOG = LogFactory.getLog(RolServiceImpl.class);

	@Autowired
	private RolDAO rolDAO;

	@Override
	public List<RoleBean> listar(RoleBean obj) throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RoleBean> todo() throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void guardar(RoleBean o) throws SystemServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public RoleBean get(Long id) throws SystemServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void habilitar(RoleBean obj, boolean activo) throws SystemServiceException {
		// TODO Auto-generated method stub
		
	}
	

	
}
