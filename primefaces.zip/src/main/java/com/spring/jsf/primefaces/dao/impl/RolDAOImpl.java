package com.spring.jsf.primefaces.dao.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.dao.RolDAO;
import com.spring.jsf.primefaces.entitys.Role;
import com.spring.jsf.primefaces.util.RepositoryDAO;

@Repository("RolDAO")
public class RolDAOImpl extends RepositoryDAO<Role> implements RolDAO {
	private Log LOG = LogFactory.getLog(RolDAOImpl.class);

}
