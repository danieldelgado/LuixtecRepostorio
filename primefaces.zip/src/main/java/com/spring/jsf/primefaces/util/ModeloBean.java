package com.spring.jsf.primefaces.util;

public class ModeloBean {

}
