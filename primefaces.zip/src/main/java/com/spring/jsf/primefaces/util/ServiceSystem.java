package com.spring.jsf.primefaces.util;

import java.util.List;

public interface ServiceSystem<T extends ModeloBean> {
		
	void guardar(T o) throws SystemServiceException;
	T get(Long id)  throws SystemServiceException;
	void habilitar(T obj, boolean activo) throws SystemServiceException;
	List<T> todo() throws SystemServiceException;

}
