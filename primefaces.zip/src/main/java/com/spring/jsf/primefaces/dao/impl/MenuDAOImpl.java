package com.spring.jsf.primefaces.dao.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.spring.jsf.primefaces.bean.MenuBean;
import com.spring.jsf.primefaces.dao.MenuDAO;
import com.spring.jsf.primefaces.entitys.Menu;
import com.spring.jsf.primefaces.util.RepositoryDAO;
import com.spring.jsf.primefaces.util.SystemDAOException;

@Repository("MenuDAO")
public class MenuDAOImpl extends RepositoryDAO<Menu> implements MenuDAO  {
	private Log LOG = LogFactory.getLog(MenuDAOImpl.class);

	@Override
	public List<Menu> listar(MenuBean obj) throws SystemDAOException {
		LOG.info("listar");
		
		
		return null;
	}

	
}
