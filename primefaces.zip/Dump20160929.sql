-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sistemabasico
-- ------------------------------------------------------
-- Server version	5.0.96-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `componente`
--

DROP TABLE IF EXISTS `componente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `componente` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `accion` varchar(255) default NULL,
  `funcion` varchar(255) default NULL,
  `icono` varchar(255) default NULL,
  `recursoId` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `recursoId` (`recursoId`),
  KEY `FK5C265F28AF2D8C9D` (`recursoId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `componente`
--

LOCK TABLES `componente` WRITE;
/*!40000 ALTER TABLE `componente` DISABLE KEYS */;
/*!40000 ALTER TABLE `componente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `icono` varchar(255) default NULL,
  `opcionMenu` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `menuP` bigint(20) default NULL,
  `recursoId` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `recursoId` (`recursoId`),
  KEY `FK240D5F26398120` (`menuP`),
  KEY `FK240D5FAF2D8C9D` (`recursoId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permiso` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `objeto` varchar(255) default NULL,
  `permitido` tinyint(1) default NULL,
  `tipoPermiso` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso`
--

LOCK TABLES `permiso` WRITE;
/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permiso_recurso`
--

DROP TABLE IF EXISTS `permiso_recurso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permiso_recurso` (
  `permisoId` bigint(20) NOT NULL,
  `recursoId` bigint(20) NOT NULL,
  KEY `FKCF0C1B9F28FFB435` (`permisoId`),
  KEY `FKCF0C1B9FAF2D8C9D` (`recursoId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso_recurso`
--

LOCK TABLES `permiso_recurso` WRITE;
/*!40000 ALTER TABLE `permiso_recurso` DISABLE KEYS */;
/*!40000 ALTER TABLE `permiso_recurso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurso`
--

DROP TABLE IF EXISTS `recurso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurso` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `descripcion` varchar(255) default NULL,
  `tipoRecurso` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurso`
--

LOCK TABLES `recurso` WRITE;
/*!40000 ALTER TABLE `recurso` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol_permisos`
--

DROP TABLE IF EXISTS `rol_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol_permisos` (
  `roleId` bigint(20) NOT NULL,
  `permisoId` bigint(20) NOT NULL,
  KEY `FK2AB903EE28FFB435` (`permisoId`),
  KEY `FK2AB903EEE8E39D57` (`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_permisos`
--

LOCK TABLES `rol_permisos` WRITE;
/*!40000 ALTER TABLE `rol_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `rol_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `descripcion` varchar(255) default NULL,
  `role` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,1,'2',NULL,NULL,NULL,NULL,'ADMIN','ADMIN'),(2,1,'1',NULL,NULL,NULL,NULL,'USUARIO','USUARIO');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` bigint(20) NOT NULL auto_increment,
  `activo` tinyint(1) default NULL,
  `codigo` varchar(255) default NULL,
  `fechaActualiza` datetime default NULL,
  `fechaCrea` datetime default NULL,
  `idUsuarioActualiza` bigint(20) default NULL,
  `idUsuarioCrea` bigint(20) default NULL,
  `apellidoMaterno` varchar(255) default NULL,
  `apellidoPaterno` varchar(255) default NULL,
  `emial` varchar(255) default NULL,
  `nombre` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,1,'1',NULL,NULL,NULL,NULL,'wf','wefw','admin@admin.com','admin','admin'),(2,1,'2',NULL,NULL,NULL,NULL,'wf','wefw','admin2@admin.com','usuario','usuario');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_roles`
--

DROP TABLE IF EXISTS `usuario_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_roles` (
  `usuarioId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  KEY `FK4D484A6C67E11927` (`usuarioId`),
  KEY `FK4D484A6CE8E39D57` (`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_roles`
--

LOCK TABLES `usuario_roles` WRITE;
/*!40000 ALTER TABLE `usuario_roles` DISABLE KEYS */;
INSERT INTO `usuario_roles` VALUES (1,1),(2,2);
/*!40000 ALTER TABLE `usuario_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-29 18:55:13
