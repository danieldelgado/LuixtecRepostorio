package com.luxitec.movego.api;

import com.luxitec.movego.util.entidades.EntityBean;


public class ImagenBean extends EntityBean{

	private String urlRuta;
	private TipoImagen tipoImagen;
	
	public String getUrlRuta() {
		return urlRuta;
	}
	public void setUrlRuta(String urlRuta) {
		this.urlRuta = urlRuta;
	}
	public TipoImagen getTipoImagen() {
		return tipoImagen;
	}
	public void setTipoImagen(TipoImagen tipoImagen) {
		this.tipoImagen = tipoImagen;
	}

	
	
	
}
