package com.luxitec.movego.util.excepciones;

public class MoveGoException extends Exception {
	private static final long serialVersionUID = 1L;
	private int codigoError;
	private String errorMessage;
	

	public MoveGoException(int codigoError,String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.codigoError = codigoError;
	}

	public MoveGoException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}
	
	public MoveGoException(int codigoError) {
		super("Error del sistema");
		this.codigoError = codigoError;
	}
	

	public int getCodigoError() {
		return codigoError;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	

	public MoveGoException() {
		super();
	}
}
