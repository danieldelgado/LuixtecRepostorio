package com.luxitec.movego.util.entidades;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class EntityDAO  {
	
	protected  Long id;
	
	protected  boolean activo;
	protected  Date fechaRegistro;
	protected  Long idUsuarioRegistra;
	protected  Date fechaActualizacion;
	protected  Long idUsuarioModifica;


	public EntityDAO() {
		super();
	}
	

	public EntityDAO(Long id, boolean activo, Date fechaRegistro, Long idUsuarioRegistra, Date fechaActualizacion, Long idUsuarioModifica) {
		super();
		this.id = id;
		this.activo = activo;
		this.fechaRegistro = fechaRegistro;
		this.idUsuarioRegistra = idUsuarioRegistra;
		this.fechaActualizacion = fechaActualizacion;
		this.idUsuarioModifica = idUsuarioModifica;
	}

	public EntityDAO(Long id) {
		super();
		this.id = id;
	}
	
	
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public Long getIdUsuarioRegistra() {
		return idUsuarioRegistra;
	}
	public void setIdUsuarioRegistra(Long idUsuarioRegistra) {
		this.idUsuarioRegistra = idUsuarioRegistra;
	}
	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public Long getIdUsuarioModifica() {
		return idUsuarioModifica;
	}
	public void setIdUsuarioModifica(Long idUsuarioModifica) {
		this.idUsuarioModifica = idUsuarioModifica;
	}

	
	
	
}
