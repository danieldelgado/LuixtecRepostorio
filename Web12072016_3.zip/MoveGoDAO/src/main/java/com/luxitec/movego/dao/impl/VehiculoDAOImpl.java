package com.luxitec.movego.dao.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.VehiculoDAO;
import com.luxitec.movego.domain.Vehiculo;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("VehiculoDAO")
public class VehiculoDAOImpl  extends RepositoryDAO<Vehiculo> implements VehiculoDAO {

	@Override
	public Vehiculo getVehiculoActual(long idUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Vehiculo> getListaVehiculos(long idUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

}
