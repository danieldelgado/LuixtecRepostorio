package com.luxitec.movego.dao;

import com.luxitec.movego.domain.Ruta;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface RutaDAO  extends IRepositoryDAO<Ruta>{

	Ruta getLastRutaPorSolicitud(long solicitudId);
	Ruta getLastRutaPorUsuarioSolicitante(long usuario);
	
}
