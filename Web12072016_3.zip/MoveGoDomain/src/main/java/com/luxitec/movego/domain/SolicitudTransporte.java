package com.luxitec.movego.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "SOLICITUD_TRANSPORTE")
public class SolicitudTransporte  extends EntityDAO{
	
	private Ruta ruta;
	
	private String tiempoEstimado;
	private String tiempoFinalizado;
	
	private String costoEstimado;
	private String costoFinal;
	private Date fechaSolicitud;
	
	private boolean trayectoriaTerminada;
	
	private EstadoTransporte estadoTransporte;
	
	

	public String getTiempoEstimado() {
		return tiempoEstimado;
	}
	
	public void setTiempoEstimado(String tiempoEstimado) {
		this.tiempoEstimado = tiempoEstimado;
	}
	public String getTiempoFinalizado() {
		return tiempoFinalizado;
	}
	public void setTiempoFinalizado(String tiempoFinalizado) {
		this.tiempoFinalizado = tiempoFinalizado;
	}
	public String getCostoEstimado() {
		return costoEstimado;
	}
	public void setCostoEstimado(String costoEstimado) {
		this.costoEstimado = costoEstimado;
	}
	public String getCostoFinal() {
		return costoFinal;
	}
	public void setCostoFinal(String costoFinal) {
		this.costoFinal = costoFinal;
	}	
	@Transient
	public boolean isTrayectoriaTerminada() {
		return trayectoriaTerminada;
	}
	public void setTrayectoriaTerminada(boolean trayectoriaTerminada) {
		this.trayectoriaTerminada = trayectoriaTerminada;
	}
	public EstadoTransporte getEstadoTransporte() {
		return estadoTransporte;
	}
	public void setEstadoTransporte(EstadoTransporte estadoTransporte) {
		this.estadoTransporte = estadoTransporte;
	}
	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}
	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	@ManyToOne
	@JoinColumn(name = "ruta")
	public Ruta getRuta() {
		return ruta;
	}

	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}
	
	
}
