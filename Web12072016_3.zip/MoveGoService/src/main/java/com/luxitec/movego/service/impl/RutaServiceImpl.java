package com.luxitec.movego.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.RutaBean;
import com.luxitec.movego.dao.RutaDAO;
import com.luxitec.movego.service.RutaService;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("RutaService")
public class RutaServiceImpl implements RutaService {

	@Autowired
	private RutaDAO rutaDAO;
	
	@Override
	public void guardar(RutaBean o) throws MoveGoServiceException {
		
		
	}

	@Override
	public RutaBean get(Long id) throws MoveGoServiceException {
	
		return null;
	}

	@Override
	public RutaBean getUltimaRuta(Long idUsuarioSolicitante) throws MoveGoServiceException {
		
		return null;
	}

	@Override
	public List<RutaBean> getRutasUsuario(Long idUsuarioSolicitante) throws MoveGoServiceException {
		
		return null;
	}

	@Override
	public void anularRuta(RutaBean rutaBean) throws MoveGoServiceException {
		
		
	}

	@Override
	public void habilitar(RutaBean obj, boolean activo) throws MoveGoServiceException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<RutaBean> todo() throws MoveGoServiceException {
		// TODO Auto-generated method stub
		return null;
	}

}
