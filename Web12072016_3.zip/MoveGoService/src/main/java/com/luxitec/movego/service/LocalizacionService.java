package com.luxitec.movego.service;

import java.util.List;
import java.util.Map;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface LocalizacionService extends IService<LocalizacionBean>{

	public static final String TIEMPO_KEY = "tiempo";
	public static final String DISTANCIA_KEY = "distancia";
	public static final String PRECIO_KEY = "precio";
	
	List<LocalizacionBean> getLocalizacionCercanas(LocalizacionBean origen, int radioKm,  Long[] idsUsuariosActivos ) throws MoveGoServiceException;
	Map<String,Object>  estimarEntrePuntos( LocalizacionBean origen,LocalizacionBean destino) throws MoveGoServiceException;//calcula en milisegundos
	LocalizacionBean getUltimaUbicacion(Long idUsuario) throws MoveGoServiceException;
	List<LocalizacionBean> getListaConductores(Long[] idsConductoresActivos)throws MoveGoServiceException;
	List<LocalizacionBean> getListaUsuarios(Long[] idsUusariosActivos)throws MoveGoServiceException;
	
}
