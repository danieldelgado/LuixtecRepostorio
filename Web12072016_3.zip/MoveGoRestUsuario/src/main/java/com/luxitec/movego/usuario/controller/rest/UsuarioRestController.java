package com.luxitec.movego.usuario.controller.rest;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.ImagenBean;
import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.bean.VehiculoBean;
import com.luxitec.movego.service.UsuarioService;
import com.luxitec.movego.tipos.TipoDocumento;
import com.luxitec.movego.tipos.TipoUsuario;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@RestController
@RequestMapping("/usuario")
public class UsuarioRestController extends com.luxitec.movego.util.controller.RestController {

	private static final Logger LOG = LoggerFactory.getLogger(UsuarioRestController.class);

	@Autowired
	private UsuarioService usuarioService;

	/**
	 * 
	 * @param id
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public UsuarioBean getUsuario(@PathVariable Long id) throws MoveGoControllerException {
		UsuarioBean u = null;
		try {
			u = new UsuarioBean();
			u.setId(id);
			u = usuarioService.get(u.getId());
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return u;
	}

	/**
	 * 
	 * @param email
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/email", method = RequestMethod.GET)
	public UsuarioBean getUsuarioByEmail(@RequestParam("email") String email) throws MoveGoControllerException {
		UsuarioBean u = null;
		try {
			u = usuarioService.getUsuarioForEmail(email);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return u;
	}

	/**
	 * 
	 * @param usuario
	 * @return
	 * @throws MoveGoControllerException
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public @ResponseBody List<UsuarioBean> getUsuarios(
			@RequestParam(value = "tipoUsuario" , required=false ) String tipoUsuario, 
			@RequestParam(value = "nombre" , required=false ) String nombre, 
			@RequestParam(value = "apellidoPaterno" , required=false ) String apellidoPaterno, 
			@RequestParam(value = "apellidoMaterno" , required=false ) String apellidoMaterno,
			@RequestParam(value = "numeroDocumento" , required=false ) String numeroDocumento, 
			@RequestParam(value = "tipoDocumento" , required=false ) String tipoDocumento, 
			@RequestParam(value = "email" , required=false ) String email, 
			@RequestParam(value = "tieneVehiculo" , required=false ) boolean tieneVehiculo,
			@RequestParam(value = "idVehiculoActual" , required=false ) Long idVehiculoActual) throws MoveGoControllerException {
		List<UsuarioBean> lu = null;
		UsuarioBean usuario = new UsuarioBean();
		if(SimpleValidador.isNotClean(tipoUsuario)){
			usuario.setTipoUsuario(TipoUsuario.valueOf(tipoUsuario));			
		}
		usuario.setNombre(nombre);
		usuario.setApellidoPaterno(apellidoPaterno);
		usuario.setApellidoMaterno(apellidoMaterno);
		if(SimpleValidador.isNotClean(tipoDocumento)){
			usuario.setTipoDocumento(TipoDocumento.valueOf(tipoDocumento));			
		}
		usuario.setNumeroDocumento(numeroDocumento);
		usuario.setEmail(email);
		usuario.setTieneVehiculo(tieneVehiculo);
		usuario.setIdVehiculoActual(idVehiculoActual);		
		try {
			lu = usuarioService.getUsuarios(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return lu;
	}

	/**
	 * 
	 * @param usuario
	 * @param result
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public UsuarioBean registrarse(@RequestBody @Valid UsuarioBean usuario, BindingResult result) throws MoveGoControllerException {
		try {
			if (result.hasErrors()) {
				throw new MoveGoControllerException(ConstantesUtil.Errors.ERROR_ENTIDAD_VALIDAR, messageSource.getMessage(ConstantesUtil.Errors.MENSAJE_VALIDADCION_INCORRECTA, null, null), result);
			}
			usuarioService.guardar(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage(), result);
		}
		return usuario;
	}

	/**
	 * 
	 * @param usuario
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.PUT)
	public UsuarioBean actualizar(@RequestBody UsuarioBean usuario) throws MoveGoControllerException {
		try {
			usuarioService.guardar(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return usuario;
	}

	/**
	 * 
	 * @param id
	 * @return
	 * @throws MoveGoControllerException
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public int eliminar(@PathVariable int id) throws MoveGoControllerException {
		UsuarioBean a = new UsuarioBean();
		a.setActivo(false);
		try {
			usuarioService.habilitar(a, UsuarioBean.IN_ACTIVO);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return ConstantesUtil.TRANSACCION_OK;
	}

}