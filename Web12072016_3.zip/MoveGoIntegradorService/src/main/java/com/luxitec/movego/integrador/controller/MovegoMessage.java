package com.luxitec.movego.integrador.controller;

import com.luxitec.movego.integrador.bean.Localizacion;
import com.luxitec.movego.integrador.bean.Usuario;

public class MovegoMessage {

	public static final String COMMAND_CONNECT="3";
	public static final String COMMAND_LOCALIZACION="0";
	public static final String COMMAND_CONFIRMAR_SOLICITUD="1";
	public static final String COMMAND_SOLICITUD="2";
	
	private String command;
	private String mensaje;
	private String error;
	private Usuario usuario;
	private Localizacion localizacion;
	
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Localizacion getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(Localizacion localizacion) {
		this.localizacion = localizacion;
	}
	
	
	
	
}
