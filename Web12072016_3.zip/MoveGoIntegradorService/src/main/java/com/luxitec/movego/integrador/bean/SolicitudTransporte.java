package com.luxitec.movego.integrador.bean;

import java.io.Serializable;

public class SolicitudTransporte  implements Serializable {

}
