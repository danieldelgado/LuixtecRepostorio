package com.luxitec.movego.integrador.bean;

import java.io.Serializable;

public class Localizacion implements Serializable{
	
	private String latitud;
	private String longitud;
	public String getLatitud() {
		return latitud;
	}
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	public String getLongitud() {
		return longitud;
	}
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	
	
}
