package com.luxitec.movego.integrador.bean;

import java.io.Serializable;


public class UsuarioMensajeSender implements Serializable {

	public static final String COMMAND_INICIO_SESSION="1";
	public static final String COMMAND_CONNECTADO_SESSION="2";
	public static final String COMMAND_DESCONNECTADO_SESSION="3";
	public static final String COMMAND_LOCALIZACION="4";
	
	private String commando;
	private SolicitudTransporte solicitudTransporte;
	private Usuario usuario;
	private Localizacion localizacion;
	public String getCommando() {
		return commando;
	}
	public void setCommando(String commando) {
		this.commando = commando;
	}
	public SolicitudTransporte getSolicitudTransporte() {
		return solicitudTransporte;
	}
	public void setSolicitudTransporte(SolicitudTransporte solicitudTransporte) {
		this.solicitudTransporte = solicitudTransporte;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Localizacion getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(Localizacion localizacion) {
		this.localizacion = localizacion;
	}
	
	
	
	
}
