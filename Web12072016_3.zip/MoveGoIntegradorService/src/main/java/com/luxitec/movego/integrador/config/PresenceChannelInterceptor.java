package com.luxitec.movego.integrador.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;

import com.luxitec.movego.integrador.service.IntegradorService;

public class PresenceChannelInterceptor extends ChannelInterceptorAdapter {

	private final Logger logger = LoggerFactory.getLogger(PresenceChannelInterceptor.class);

	@Autowired
	private IntegradorService integradorService;
	
	@SuppressWarnings("incomplete-switch")
	@Override
	public void postSend(Message<?> message, MessageChannel channel, boolean sent) {
		StompHeaderAccessor sha = StompHeaderAccessor.wrap(message);
		if (sha.getCommand() == null) {
			return;
		}
		String sessionId = sha.getSessionId();
		logger.info("sha.getCommand():"+sha.getCommand());
		switch (sha.getCommand()) {
		case CONNECT:
			logger.info("STOMP Connect [sessionId: " + sessionId + "]");			
			try {
				String login = sha.getLogin();
				String passcode = sha.getPasscode();
		        String token = sha.getNativeHeader("token").get(0);
				logger.info("login:"+login+"| passcode"+passcode+"| token"+token);
				integradorService.instanciarConexion(sessionId,token,login,passcode);
				logger.info("Conexion establecida");
			} catch (Exception e) {
				logger.info("Conexion no se pudo establecer");
				logger.error("Excp:",e);
			}			
			break;
		case CONNECTED:
			logger.info("STOMP Connected [sessionId: " + sessionId + "]");
			break;
		case DISCONNECT:
			logger.info("STOMP Disconnect [sessionId: " + sessionId + "]");
			try {
				String login = sha.getLogin();
		        String token = sha.getNativeHeader("token").get(0);
				logger.info("login:"+login+"| token"+token);
				integradorService.terminarConexion(sessionId);
				logger.info("Conexion establecida");
			} catch (Exception e) {
				logger.info("Conexion no se pudo establecer");
				logger.error("Excp:",e);
			}
			break;
		case SUBSCRIBE:
			logger.info("STOMP SUBSCRIBE [sessionId: " + sessionId + "]");
			break;
		case UNSUBSCRIBE:
			logger.info("STOMP UNSUBSCRIBE [sessionId: " + sessionId + "]");
			break;		
		}
	}
}