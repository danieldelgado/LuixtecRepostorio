package com.luxitec.movego.config;

import javax.jms.JMSException;
import javax.jms.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;


@Component
public class MessageReceiver {

	static final Logger LOG = LoggerFactory.getLogger(MessageReceiver.class);
	private static final String ORDER_QUEUE = "order-queue";
	
//	@JmsListener(destination = ORDER_QUEUE)
//	public void receiveMessage(final Message<Object> message) throws JMSException {
//		LOG.info("----------------------------------------------------");
//		MessageHeaders headers =  message.getHeaders();
//		LOG.info("Application : headers received : {}", headers);
//		
////		Product product = message.getPayload();
////		LOG.info("Application : product : {}",product);	
////
////		orderService.processOrder(product);
//		LOG.info("----------------------------------------------------");
//
//	}
	
}
