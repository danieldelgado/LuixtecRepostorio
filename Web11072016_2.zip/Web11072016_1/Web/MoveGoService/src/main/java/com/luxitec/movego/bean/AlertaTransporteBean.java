package com.luxitec.movego.bean;

import java.util.Date;

public class AlertaTransporteBean {

	private long id;
	private String titulo;
	private String mensaje;

	private boolean enviado;
	private Date fechaEnviado;
	private boolean recibido;
	private Date fechaRecibido;
	private boolean activo;
	
	private Date fechaRegistro;
	private long idUsuarioRegistra;
	private Date fechaActualizacion;
	private long idUsuarioModifica;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public boolean isEnviado() {
		return enviado;
	}
	public void setEnviado(boolean enviado) {
		this.enviado = enviado;
	}
	public Date getFechaEnviado() {
		return fechaEnviado;
	}
	public void setFechaEnviado(Date fechaEnviado) {
		this.fechaEnviado = fechaEnviado;
	}
	public boolean isRecibido() {
		return recibido;
	}
	public void setRecibido(boolean recibido) {
		this.recibido = recibido;
	}
	public Date getFechaRecibido() {
		return fechaRecibido;
	}
	public void setFechaRecibido(Date fechaRecibido) {
		this.fechaRecibido = fechaRecibido;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public long getIdUsuarioRegistra() {
		return idUsuarioRegistra;
	}
	public void setIdUsuarioRegistra(long idUsuarioRegistra) {
		this.idUsuarioRegistra = idUsuarioRegistra;
	}
	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public long getIdUsuarioModifica() {
		return idUsuarioModifica;
	}
	public void setIdUsuarioModifica(long idUsuarioModifica) {
		this.idUsuarioModifica = idUsuarioModifica;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
	
	
}
