package com.luxitec.movego.controller.rest.test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.config.ApplicationMoveGoConfig;
import com.luxitec.movego.util.Util;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApplicationMoveGoConfig.class })
@WebAppConfiguration
public class LocalizacionRestControllerTest {

	private static final String URL_BASIC = "http://localhost:8080/MoveGoRestLocalizacion/localizacion/";
	private static final String URL_RADIO = URL_BASIC + "radio/";

	String radioKm = "";
	String json = "";

	LocalizacionBean localizacion = null;
	LocalizacionBean origen = null;
	Long[] idsUsuariosActivos;

	@Before
	public void init() throws Exception {

		localizacion = new LocalizacionBean();
		localizacion.setActivo(true);
		localizacion.setDireccionActual("av. guiberty 135");
		localizacion.setLatitud("-12.354645");
		localizacion.setLongitud("-77.34534534");
		localizacion.setIdUsuario(2);

		origen = new LocalizacionBean();
		origen.setIdUsuario(2);
		origen.setLatitud("-12.354622");
		origen.setLongitud("-77.34534234");
		radioKm = "5";
		Long[] ids = { 1L, 2L };
		idsUsuariosActivos = ids;

	}

	@Test
	public void registrarLocalizacion_test() {
		try {

			json = Util.getJson(localizacion);
			HttpResponse r = Util.post(URL_BASIC, json);
			String res = Util.getEntry(r);
			System.out.println(res);
			Assert.assertNotNull(res);

		} catch (SocketException se) {
			se.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void getLocalizacionCercanas_test() throws Exception {
		try {
			Map<String, String> params = new LinkedHashMap<String, String>();
			params.put("idsUsuariosActivos", "\"" + Util.convert(idsUsuariosActivos) + "\"");
			params.put("idusuario", String.valueOf(origen.getIdUsuario()));
			params.put("latitud", origen.getLatitud());
			params.put("longitud", origen.getLongitud());
			HttpResponse r = Util.get(URL_RADIO + radioKm,params);
			String res = Util.getEntry(r);
			System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
