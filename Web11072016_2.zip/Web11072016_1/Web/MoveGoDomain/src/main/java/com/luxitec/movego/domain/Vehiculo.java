package com.luxitec.movego.domain;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "VEHICULO")
public class Vehiculo  extends EntityDAO{
	
	private String marca;
	private String modelo;
	private String placa;
	private String soat;
	private Long idUsuario;
	
	private Usuario usuarioConductor;

	private Long idImagen;
	
	private Imagen imagenVehiculo;
	
	public Long getIdUsuario() {
		return idUsuario;
	}



	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}



	public Long getIdImagen() {
		return idImagen;
	}



	public void setIdImagen(Long idImagen) {
		this.idImagen = idImagen;
	}



	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getSoat() {
		return soat;
	}
	public void setSoat(String soat) {
		this.soat = soat;
	}
	
	@Transient
	public Imagen getImagenVehiculo() {
		return imagenVehiculo;
	}
	public void setImagenVehiculo(Imagen imagenVehiculo) {
		this.imagenVehiculo = imagenVehiculo;
	}



	@ManyToOne
	@JoinColumn(name = "usuario_conductor")
	public Usuario getUsuarioConductor() {
		return usuarioConductor;
	}



	public void setUsuarioConductor(Usuario usuarioConductor) {
		this.usuarioConductor = usuarioConductor;
	}
	
	
}
