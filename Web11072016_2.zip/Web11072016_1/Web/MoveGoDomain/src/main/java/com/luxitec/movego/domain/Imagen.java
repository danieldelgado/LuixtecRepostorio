package com.luxitec.movego.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.luxitec.movego.tipos.TipoImagen;
import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "IMAGEN")
public class Imagen  extends EntityDAO{

	private String urlRuta;
	private TipoImagen tipoImagen;
	
	public String getUrlRuta() {
		return urlRuta;
	}
	public void setUrlRuta(String urlRuta) {
		this.urlRuta = urlRuta;
	}
	public TipoImagen getTipoImagen() {
		return tipoImagen;
	}
	public void setTipoImagen(TipoImagen tipoImagen) {
		this.tipoImagen = tipoImagen;
	}


	
	
}
