package com.luxitec.movego.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.luxitec.movego.tipos.TipoDocumento;
import com.luxitec.movego.tipos.TipoUsuario;
import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "USUARIO")
public class Usuario extends EntityDAO {
//	public final static int ESTADO_ONLINE = 1;
//	public final static int ESTADO_OFF_LINE = 0;

	private TipoUsuario tipoUsuario;

	private String nombre;
	private String apellidoPaterno;
	private String apellidoMaterno;
	
	private String numeroDocumento;
	private TipoDocumento tipoDocumento;

	private String email;

	private String contrasenna;

	private String idDispositivo;	
	private String numeroTelefono;
	
	private List<Localizacion> listaLocalizacion;

	private boolean tieneVehiculo;
	
	private boolean online;

	private Long idVehiculoActual;

	private Vehiculo vehiculoActual;

	private List<Vehiculo> listaVehiculo;

	private List<Imagen> listaImagen;

	private Long idUtlimaLocazion;

	private Localizacion utlimaLocazion;

	public Usuario(){
		
	}

	public Usuario(Long id, String nombre, String apellidoPaterno, String apellidoMaterno, String email) {
		super(id);
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.email = email;
	}
	
	
	public Usuario(Long id, String nombre, String apellidoPaterno, String apellidoMaterno, String email, String idDispositivo, String numeroTelefono ) {
		super(id);
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.email = email;
		this.idDispositivo = idDispositivo;
		this.numeroTelefono = numeroTelefono;
	}
	

	public Usuario(Long id, String nombre, String apellidoPaterno, String apellidoMaterno, String email, boolean online) {
		super(id);
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.email = email;
		this.online = online;
	}
	
	
	public Usuario(Long id, String nombre, String apellidoPaterno, String apellidoMaterno, String email, String idDispositivo, String numeroTelefono , boolean online) {
		super(id);
		this.nombre = nombre;
		this.apellidoPaterno = apellidoPaterno;
		this.apellidoMaterno = apellidoMaterno;
		this.email = email;
		this.idDispositivo = idDispositivo;
		this.numeroTelefono = numeroTelefono;
		this.online = online;
	}
	
	public String getIdDispositivo() {
		return idDispositivo;
	}

	public void setIdDispositivo(String idDispositivo) {
		this.idDispositivo = idDispositivo;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public TipoUsuario getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(TipoUsuario tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isTieneVehiculo() {
		return tieneVehiculo;
	}

	public void setTieneVehiculo(boolean tieneVehiculo) {
		this.tieneVehiculo = tieneVehiculo;
	}

	public Long getIdVehiculoActual() {
		return idVehiculoActual;
	}

	public void setIdVehiculoActual(Long idVehiculoActual) {
		this.idVehiculoActual = idVehiculoActual;
	}

	public Long getIdUtlimaLocazion() {
		return idUtlimaLocazion;
	}

	public void setIdUtlimaLocazion(Long idUtlimaLocazion) {
		this.idUtlimaLocazion = idUtlimaLocazion;
	}

	@Transient
	public Vehiculo getVehiculoActual() {
		return vehiculoActual;
	}

	public void setVehiculoActual(Vehiculo vehiculoActual) {
		this.vehiculoActual = vehiculoActual;
	}
	
	@Transient
	public Localizacion getUtlimaLocazion() {
		return utlimaLocazion;
	}

	public void setUtlimaLocazion(Localizacion utlimaLocazion) {
		this.utlimaLocazion = utlimaLocazion;
	}

	@OneToMany
	@JoinColumn(name="vehiculos") 
	public List<Vehiculo> getListaVehiculo() {
		return listaVehiculo;
	}

	public void setListaVehiculo(List<Vehiculo> listaVehiculo) {
		this.listaVehiculo = listaVehiculo;
	}
	
	@OneToMany
	@JoinColumn(name="localizaciones") 
	public List<Localizacion> getListaLocalizacion() {
		return listaLocalizacion;
	}

	public void setListaLocalizacion(List<Localizacion> listaLocalizacion) {
		this.listaLocalizacion = listaLocalizacion;
	}

	@OneToMany
	@JoinColumn(name="imagen_tipo")
	public List<Imagen> getListaImagen() {
		return listaImagen;
	}

	public void setListaImagen(List<Imagen> listaImagen) {
		this.listaImagen = listaImagen;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public boolean isOnline() {
		return online;
	}

	public void setOnline(boolean online) {
		this.online = online;
	}

	public String getContrasenna() {
		return contrasenna;
	}

	public void setContrasenna(String contrasenna) {
		this.contrasenna = contrasenna;
	}
	

}
