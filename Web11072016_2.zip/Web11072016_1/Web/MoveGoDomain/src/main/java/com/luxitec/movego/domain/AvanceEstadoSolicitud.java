package com.luxitec.movego.domain;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "AVANCE_ESTADO_SOLICITUD")
public class AvanceEstadoSolicitud extends EntityDAO {

	private SolicitudTransporte solicitud;
	private EstadoTransporte estadoTransporte;

	@ManyToOne
	@JoinColumn(name = "solicitud")
	public SolicitudTransporte getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SolicitudTransporte solicitud) {
		this.solicitud = solicitud;
	}

	public EstadoTransporte getEstadoTransporte() {
		return estadoTransporte;
	}

	public void setEstadoTransporte(EstadoTransporte estadoTransporte) {
		this.estadoTransporte = estadoTransporte;
	}

}
