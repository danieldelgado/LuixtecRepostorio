package com.luxitec.movego.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;

import com.luxitec.movego.util.Util;
import com.luxitec.movego.util.excepciones.MoveGoException;

public class UsuarioAPI {

	private static final String URL_CONTEXT = "http://" + PropertiesInstant.getValue("host.usuario") + ":" + PropertiesInstant.getValue("puerto.usuario") + "/" + PropertiesInstant.getValue("contexto.usuario");
	private static final String URL_CONTEXT_LOGIN = URL_CONTEXT + "login/";
	private static final String URL_CONTEXT_EXITE_USUARIO = URL_CONTEXT_LOGIN + "usuario/";
	private static final String URL_CONTEXT_REGISTRARSE = URL_CONTEXT_LOGIN + "registrarse/";

	private static final String URL_CONTEXT_USUARIO = URL_CONTEXT + "usuario/";
	private static final String URL_CONTEXT_EMAIL = URL_CONTEXT_USUARIO + "email/";

	public static UsuarioBean iniciarSession(String email, String password) throws ClientProtocolException, IOException, MoveGoException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("email", email);
		params.put("password", password);
//		System.out.println(URL_CONTEXT_LOGIN);
		HttpResponse r = Util.post(URL_CONTEXT_LOGIN, params);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			UsuarioBean u = (UsuarioBean) Util.getObject(res, UsuarioBean.class);
			return u;
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static int exiteUsuario(String email) throws ClientProtocolException, IOException, MoveGoException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("email", email );
		HttpResponse r = Util.get(URL_CONTEXT_EXITE_USUARIO, params);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			return new Integer(res);
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static UsuarioBean registrarse(UsuarioBean usuario) throws ClientProtocolException, IOException, MoveGoException {		
		String json = Util.getJson(usuario);
		HttpResponse r = Util.post(URL_CONTEXT_REGISTRARSE, json);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			usuario = (UsuarioBean) Util.getObject(res, UsuarioBean.class);
			return usuario;
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static UsuarioBean getUsuario(Long id) throws MoveGoException, ClientProtocolException, IOException {
		HttpResponse r = Util.get(URL_CONTEXT_USUARIO+id, null);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			UsuarioBean	usuario = (UsuarioBean) Util.getObject(res, UsuarioBean.class);
			return usuario;
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static UsuarioBean getUsuarioByEmail(String email) throws ClientProtocolException, IOException, MoveGoException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("email", email );		
		HttpResponse r = Util.get(URL_CONTEXT_EMAIL, params);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			UsuarioBean	usuario = (UsuarioBean) Util.getObject(res, UsuarioBean.class);
			return usuario;
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static List<UsuarioBean> getUsuarios(UsuarioBean usuario) throws ClientProtocolException, IOException, Exception {
		HttpResponse r = Util.get(URL_CONTEXT_USUARIO, usuario);
		if (r.getStatusLine().getStatusCode() == 200) {
			String res = Util.getEntry(r);
			List<UsuarioBean>	l = (List<UsuarioBean>) Util.getObject(res, ArrayList.class);
			return l;
		} else {
			throw new MoveGoException(r.getStatusLine().toString());
		}
	}

	public static UsuarioBean registrarseUsuario(UsuarioBean usuario) {

		return null;
	}

	public static UsuarioBean actualizar(UsuarioBean usuario) {

		return usuario;
	}

	public static int eliminar(int id) {
		return 0;
	}

	public static void main(String[] args) {
		try {

//			System.out.println(iniciarSession("danie@qwwq.com", "1234"));
//			System.out.println(exiteUsuario("danie@qwwq.com"));

//			UsuarioBean u =  new UsuarioBean();
//			u.setActivo(true);
//			u.setNombre("daniel");
//			u.setApellidoPaterno("delg");
//			u.setApellidoMaterno("cab");
//			u.setEmail("danie@qwwq.com");
//			u.setContrasenna("1234");
//			u.setNumeroDocumento("12312323");
//			u.setTipoDocumento(TipoDocumento.DNI);
//			
//			u = registrarse(u);
//			System.out.println(u.getId());
			
//			System.out.println(getUsuario(1L));
			
//			System.out.println(getUsuarioByEmail("danie@qwwq.com"));
			
			System.out.println(getUsuarios(new UsuarioBean()));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
