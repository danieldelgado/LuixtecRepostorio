package com.luxitec.movego.api;

import java.util.List;

import com.luxitec.movego.util.entidades.EntityBean;

public class UsuarioBean extends EntityBean {
	public final static int ESTADO_ONLINE = 1;
	public final static int ESTADO_OFF_LINE = 0;
	public final static boolean ACTIVO = true;
	public final static boolean IN_ACTIVO = false;

	private TipoUsuario tipoUsuario;

	private String nombre;
	
	private String apellidoPaterno;
	
	private String apellidoMaterno;

	private String numeroDocumento;
	
	private TipoDocumento tipoDocumento;

	private String email;

	private String contrasenna;
	
	private String idDispositivo;	
	private String numeroTelefono;

	private boolean tieneVehiculo;

	private Long idVehiculoActual;

	private VehiculoBean vehiculoActual;

	private List<VehiculoBean> listaVehiculo;

	private List<ImagenBean> listaImagen;

	private Long idUtlimaLocazion;

	public TipoUsuario getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(TipoUsuario tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isTieneVehiculo() {
		return tieneVehiculo;
	}

	public void setTieneVehiculo(boolean tieneVehiculo) {
		this.tieneVehiculo = tieneVehiculo;
	}

	public Long getIdVehiculoActual() {
		return idVehiculoActual;
	}

	public void setIdVehiculoActual(Long idVehiculoActual) {
		this.idVehiculoActual = idVehiculoActual;
	}

	public VehiculoBean getVehiculoActual() {
		return vehiculoActual;
	}

	public void setVehiculoActual(VehiculoBean vehiculoActual) {
		this.vehiculoActual = vehiculoActual;
	}

	public List<VehiculoBean> getListaVehiculo() {
		return listaVehiculo;
	}

	public void setListaVehiculo(List<VehiculoBean> listaVehiculo) {
		this.listaVehiculo = listaVehiculo;
	}

	public List<ImagenBean> getListaImagen() {
		return listaImagen;
	}

	public void setListaImagen(List<ImagenBean> listaImagen) {
		this.listaImagen = listaImagen;
	}

	public Long getIdUtlimaLocazion() {
		return idUtlimaLocazion;
	}

	public void setIdUtlimaLocazion(Long idUtlimaLocazion) {
		this.idUtlimaLocazion = idUtlimaLocazion;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getContrasenna() {
		return contrasenna;
	}

	public void setContrasenna(String contrasenna) {
		this.contrasenna = contrasenna;
	}

	public String getIdDispositivo() {
		return idDispositivo;
	}

	public void setIdDispositivo(String idDispositivo) {
		this.idDispositivo = idDispositivo;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}


}
