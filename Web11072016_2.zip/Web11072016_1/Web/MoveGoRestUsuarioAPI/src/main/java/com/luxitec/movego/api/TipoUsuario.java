package com.luxitec.movego.api;

public enum TipoUsuario {
	CONDUCTO("CONDUCTO"), PASAJERO("PASAJERO");

	private String tipoUsuario;

	TipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getTipoUsuario() {
		return tipoUsuario;
	}

}
