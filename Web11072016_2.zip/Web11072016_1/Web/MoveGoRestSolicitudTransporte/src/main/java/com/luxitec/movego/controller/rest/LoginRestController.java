package com.luxitec.movego.controller.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;

@RestController
@RequestMapping("/api/v1/login")
public class LoginRestController {
	

	@RequestMapping(value = "/person", method = RequestMethod.GET)
	public UsuarioBean getPersonDetail(@RequestParam(value = "id", required = false, defaultValue = "0") Integer id) throws MoveGoControllerException {
//
////		Usuario a = new Usuario();
////		
////		System.out.println(a);
//		if (id == 0) {
//            throw new MoveGoAdapterException(678,"The 'name' parameter must not be null or empty");
//        }
//		
//		UsuarioBean p = personService.getPersonDetail(id);
		return null;
	}
	
	

}