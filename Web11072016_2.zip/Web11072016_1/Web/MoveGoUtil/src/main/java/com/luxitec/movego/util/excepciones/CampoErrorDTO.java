package com.luxitec.movego.util.excepciones;
public class CampoErrorDTO {
 
    private String campo;
 
    private String mensajeError;
 
    public CampoErrorDTO(String campo, String mensajeError) {
        this.campo = campo;
        this.mensajeError = mensajeError;
    }

	public String getCampo() {
		return campo;
	}

	public void setCampo(String campo) {
		this.campo = campo;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	
 
    
}