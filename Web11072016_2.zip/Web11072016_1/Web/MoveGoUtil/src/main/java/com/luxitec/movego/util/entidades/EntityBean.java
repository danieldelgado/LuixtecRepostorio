package com.luxitec.movego.util.entidades;

import java.util.Date;

public class EntityBean {
	protected Long id;

	protected boolean activo;

	protected Date fechaRegistro;
	
	protected Date fechaRegistroInicio;
	protected Date fechaRegistroFin;
	
	protected Long idUsuarioRegistra;

	protected Date fechaActualizacion;
	
	protected Date fechaActualizacionInicio;
	protected Date fechaActualizacionFin;
	
	protected Long idUsuarioModifica;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public Long getIdUsuarioRegistra() {
		return idUsuarioRegistra;
	}
	public void setIdUsuarioRegistra(Long idUsuarioRegistra) {
		this.idUsuarioRegistra = idUsuarioRegistra;
	}
	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public Long getIdUsuarioModifica() {
		return idUsuarioModifica;
	}
	public void setIdUsuarioModifica(Long idUsuarioModifica) {
		this.idUsuarioModifica = idUsuarioModifica;
	}
	public Date getFechaRegistroInicio() {
		return fechaRegistroInicio;
	}
	public void setFechaRegistroInicio(Date fechaRegistroInicio) {
		this.fechaRegistroInicio = fechaRegistroInicio;
	}
	public Date getFechaRegistroFin() {
		return fechaRegistroFin;
	}
	public void setFechaRegistroFin(Date fechaRegistroFin) {
		this.fechaRegistroFin = fechaRegistroFin;
	}
	public Date getFechaActualizacionInicio() {
		return fechaActualizacionInicio;
	}
	public void setFechaActualizacionInicio(Date fechaActualizacionInicio) {
		this.fechaActualizacionInicio = fechaActualizacionInicio;
	}
	public Date getFechaActualizacionFin() {
		return fechaActualizacionFin;
	}
	public void setFechaActualizacionFin(Date fechaActualizacionFin) {
		this.fechaActualizacionFin = fechaActualizacionFin;
	}
	
	
	
}
