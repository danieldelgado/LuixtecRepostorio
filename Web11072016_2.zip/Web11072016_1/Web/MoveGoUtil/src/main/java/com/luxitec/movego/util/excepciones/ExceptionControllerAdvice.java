package com.luxitec.movego.util.excepciones;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionControllerAdvice {

	private static final Logger LOG = LoggerFactory.getLogger(ExceptionControllerAdvice.class);

	@Autowired
	private MessageSource messageSource;

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("Please contact your administrator");
		LOG.error("Error Exception", ex);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}

	@ExceptionHandler(MoveGoException.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(MoveGoException ex) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(ex.getCodigoError());
		error.setMessage(ex.getErrorMessage());
		LOG.error("Error MoveGoException", ex);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}

	@ExceptionHandler(MoveGoDAOException.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(MoveGoDAOException ex) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(ex.getCodigoError());
		error.setMessage(ex.getErrorMessage());
		LOG.error("Error MoveGoDAOException", ex);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}

	@ExceptionHandler(MoveGoServiceException.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(MoveGoServiceException ex) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(ex.getCodigoError());
		error.setMessage(ex.getErrorMessage());
		LOG.error("Error MoveGoServiceException", ex);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}

	@ExceptionHandler(MoveGoControllerException.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(MoveGoControllerException ex) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorCode(ex.getCodigoError());
		error.setMessage(ex.getErrorMessage());

		BindingResult result = ex.getBindingResult();
		if (result != null && result.hasErrors()) {
			for (FieldError fieldError : result.getFieldErrors()) {
				String localizedErrorMessage = resolveLocalizedErrorMessage(fieldError);
				error.addFieldError(fieldError.getField(), localizedErrorMessage);
			}
		}
		LOG.error("Error MoveGoControllerException", ex);
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}

	private String resolveLocalizedErrorMessage(FieldError fieldError) {
		Locale currentLocale = LocaleContextHolder.getLocale();
		String localizedErrorMessage = messageSource.getMessage(fieldError, currentLocale);
		if (localizedErrorMessage.equals(fieldError.getDefaultMessage())) {
			String[] fieldErrorCodes = fieldError.getCodes();
			localizedErrorMessage = fieldErrorCodes[0];
		}
		return localizedErrorMessage;
	}

}