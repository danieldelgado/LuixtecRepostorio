package com.luxitec.movego.util.service;

public abstract class Service implements IService{
	
	
	
}
