package com.luxitec.movego.dao;

import com.luxitec.movego.domain.Imagen;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface ImagenDAO extends IRepositoryDAO<Imagen> {

	
	
}
