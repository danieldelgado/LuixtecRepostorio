package com.luxitec.movego.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.LocalizacionDAO;
import com.luxitec.movego.domain.Localizacion;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("LocalizacionDAO")
public class LocalizacionDAOImpl  extends RepositoryDAO<Localizacion> implements LocalizacionDAO{

	@Override
	public List<Localizacion> getLocalizacionCercanas(Localizacion o, int radioKm, Long[] idsUsuariosActivos) {
		
		return new ArrayList<>();
	}

	@Override
	public Localizacion getUltimaUbicacion(Long idUsuario) {
		Localizacion i = new Localizacion();
		i.setId(2L);
		return i;
	}

	@Override
	public List<Localizacion> getListaConductores(Long[] idsConductoresActivos) {
		
		return  new ArrayList<>();
	}

	@Override
	public List<Localizacion> getListaUsuarios(Long[] idsUusariosActivos) {
		

		return new ArrayList<>();
	}

	
		
}
