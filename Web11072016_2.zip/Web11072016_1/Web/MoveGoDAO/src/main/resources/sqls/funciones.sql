
--http://www.royrojas.com/calcular-la-distancia-entre-dos-puntos-por-latitud-y-longitud/
CREATE FUNCTION dn_fn_CalculaDistancia 
(
@latitud1 float,
@longitud1 float,
@latitud2 float,
@longitud2 float,
@unidad_metrica char(1)
)
RETURNS float
AS
BEGIN
 
	--Unidad Metrica: K=kilometros  M=millas 
	DECLARE @distancia float
	
	--Radio de la tierra según WGS84
	DECLARE @radius float
	SET @radius = 6378.137 
 
	DECLARE @deg2radMultiplier float 
	SET @deg2radMultiplier = PI() / 180
	
	SET @latitud1 = @latitud1 * @deg2radMultiplier
	SET @longitud1 = @longitud1 * @deg2radMultiplier
	SET @latitud2 = @latitud2 * @deg2radMultiplier
	SET @longitud2 = @longitud2 * @deg2radMultiplier
		
	DECLARE @dlongitud float
	SET @dlongitud = @longitud2 - @longitud1
		
	SET @distancia = ACOS(SIN(@latitud1) * SIN(@latitud2) + COS(@latitud1) *
					 COS(@latitud2) * COS(@dlongitud)) * @radius
	
	IF @unidad_metrica = 'M'  
	   SET @distancia = @distancia * 1000
		
	RETURN @distancia
 
END