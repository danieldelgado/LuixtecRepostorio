package com.luxitec.movego.integrador.bean;

import java.util.Date;

public class Usuario {

	private String idDispositivo;
	private String id;
	private String sessionWsId;
	private String token;
	private String login;
	private String pass;
	private String nombre;
	private String apellidos;
	private String tipoUsuario;
	private Date fechaHoraConexion;
	
	private Localizacion localizacion;
	private Vehiculo vehiculoBean;
	
	
	public String getIdDispositivo() {
		return idDispositivo;
	}
	public void setIdDispositivo(String idDispositivo) {
		this.idDispositivo = idDispositivo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getTipoUsuario() {
		return tipoUsuario;
	}
	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public Vehiculo getVehiculoBean() {
		return vehiculoBean;
	}
	public void setVehiculoBean(Vehiculo vehiculoBean) {
		this.vehiculoBean = vehiculoBean;
	}	
	public Localizacion getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(Localizacion localizacion) {
		this.localizacion = localizacion;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getSessionWsId() {
		return sessionWsId;
	}
	public void setSessionWsId(String sessionWsId) {
		this.sessionWsId = sessionWsId;
	}
	public Date getFechaHoraConexion() {
		return fechaHoraConexion;
	}
	public void setFechaHoraConexion(Date fechaHoraConexion) {
		this.fechaHoraConexion = fechaHoraConexion;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
	
	
}
