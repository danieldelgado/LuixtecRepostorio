package com.luxitec.movego.integrador.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.integrador.bean.Usuario;
import com.luxitec.movego.integrador.service.IntegradorService;

@CrossOrigin(maxAge = 3600)
@RestController
@RequestMapping("/service")
public class IntegradorServiceController {

	private final Logger logger = LoggerFactory.getLogger(IntegradorServiceController.class);

	@Autowired
	private IntegradorService integradorService;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String get() {
		logger.info("Test get");
		return "hola test";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Usuario login(@RequestParam(name = "login") String login, @RequestParam(name = "pass") String pass, HttpSession session) {
		logger.info("login");
		Usuario u = new Usuario();
		u.setLogin(login);
		u.setPass(pass);
		u = integradorService.login(u);
		return u;
	}

	@MessageMapping("/movego_ws")
	@SendTo("/topic/resultconnect")
	public MovegoResult resultconnect(MovegoMessage message) throws Exception {
		MovegoResult r = null;
		String c = message.getCommand();
		logger.info("c:"+c+" | message:"+message);
		if (c != null) {
			switch (c) {
			case MovegoMessage.COMMAND_LOCALIZACION:
				logger.info("COMMAND_LOCALIZACION");
				integradorService.registrarLocalizacion(message.getUsuario(), message.getLocalizacion());
				break;
			case MovegoMessage.COMMAND_SOLICITUD:
				logger.info("COMMAND_SOLICITUD");
				break;
			case MovegoMessage.COMMAND_CONFIRMAR_SOLICITUD:
				logger.info("COMMAND_CONFIRMAR_SOLICITUD");
				break;
			}
		}
		return r;
	}
	

}