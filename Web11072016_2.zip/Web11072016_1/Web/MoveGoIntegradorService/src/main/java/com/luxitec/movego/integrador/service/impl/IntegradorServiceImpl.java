package com.luxitec.movego.integrador.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.luxitec.movego.api.LocalizacionBean;
import com.luxitec.movego.api.LocalizazcionAPI;
import com.luxitec.movego.api.UsuarioAPI;
import com.luxitec.movego.api.UsuarioBean;
import com.luxitec.movego.integrador.bean.Localizacion;
import com.luxitec.movego.integrador.bean.Usuario;
import com.luxitec.movego.integrador.controller.MovegoResult;
import com.luxitec.movego.integrador.service.IntegradorService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Util;
import com.luxitec.movego.util.excepciones.MoveGoException;

@Service("IntegradorService")
public class IntegradorServiceImpl implements IntegradorService {

	private final Logger logger = LoggerFactory.getLogger(IntegradorServiceImpl.class);

	private static Map<String, Usuario> listaUsuarioOnline = new HashMap<>();
	private static Map<String, String> listaTokenHabilitados = new HashMap<>();

	@Override
	public Usuario login(Usuario u) {
		try {
			UsuarioBean usuario = UsuarioAPI.iniciarSession(u.getLogin(), u.getPass());
			if (SimpleValidador.isNull(usuario)) {
				return null;
			}
			u.setId(String.valueOf(usuario.getId()));
			u.setNombre(usuario.getNombre());
			u.setApellidos(usuario.getApellidoPaterno());
			u.setIdDispositivo(usuario.getIdDispositivo());
			String token = Util.token();
			u.setToken(token);
			listaTokenHabilitados.put(token, token);
			u.setFechaHoraConexion(new Date());
			u.setPass("");
			usuarioConectado(u.getLogin(), u);
		} catch (IOException | MoveGoException e) {
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public void terminarConexion(String sessionId) throws Exception {
		logger.info("terminarConexion");
		try {
			Usuario usuarioConectado = getUsuarioConectadobuSession(sessionId);
			if (SimpleValidador.isNotNull(usuarioConectado)) {
				if (usuarioIsOnline(usuarioConectado.getLogin())) {
					UsuarioBean usuario = UsuarioAPI.getUsuarioByEmail(usuarioConectado.getLogin());
					if (exiteToken(usuario.getEmail(), usuarioConectado.getToken())) {
						usuarioDesconectado(usuarioConectado.getLogin(), usuarioConectado.getToken());
					} else {
						logger.info("Usuario no encontrado");
						throw new Exception("Usuario no encontrado");
					}
				} else {
					throw new Exception("Usuario no conectado");
				}
			} else {
				throw new Exception("Session non iniciada");
			}

		} catch (IOException | MoveGoException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void instanciarConexion(String sessionId, String token, String login, String passcode) throws Exception {
		logger.info("instanciarConexion");
		try {
			if (validarConexion(login, token)) {
				UsuarioBean usuario = UsuarioAPI.iniciarSession(login, passcode);
				Usuario u = new Usuario();
				u.setLogin(login);
				u.setPass(passcode);
				u.setNombre(usuario.getNombre());
				u.setApellidos(usuario.getApellidoPaterno());
				u.setSessionWsId(sessionId);
				u.setToken(token);
				listaTokenHabilitados.put(token, sessionId);		
				listaUsuarioOnline.put(login, u);		
			} else {
				throw new Exception("Usaurio no validado en la conexion");
				
			}
		} catch (IOException | MoveGoException e) {
			e.printStackTrace();
		}
	}

	@Override
	public MovegoResult registrarLocalizacion(Usuario usuario, Localizacion localizacion) {
		MovegoResult rt = new MovegoResult();
		if (usuarioIsOnline(usuario.getLogin())) {
			rt.setError(MovegoResult.USUARIO_NO_ONLINE);
		}
		LocalizacionBean localizacionBean = new LocalizacionBean();
		localizacionBean.setIdUsuario(Long.valueOf(usuario.getId()));
		localizacionBean.setLongitud(localizacion.getLongitud());
		localizacionBean.setLatitud(localizacion.getLatitud());
		try {
			localizacionBean = LocalizazcionAPI.registrarLocalizacion(localizacionBean);
			rt.setError(MovegoResult.LOCALIZACION_REGISTRADA);
			rt.setLocalizacion(localizacion);
		} catch (IOException | MoveGoException e) {
			rt.setError(MovegoResult.LOCALIZACION_NO_REGISTRADA);
			e.printStackTrace();
		}
		return rt;
	}

	public static Usuario getUsuarioConectadobuSession(final String sessionId) {
		if (!listaUsuarioOnline.isEmpty()) {
			Usuario u = null;
			for (Map.Entry<String, Usuario> e : listaUsuarioOnline.entrySet()) {
				u = e.getValue();
				if (u.getSessionWsId().equals(sessionId)) {
					return u;
				}
			}
		}
		return null;
	}

	public static boolean exiteToken(String login, String token) {
		if (validarConexion(login, token)) {
			return true;
		}
		return false;
	}

	public synchronized static boolean validarConexion(final String login, final String token) {
		if (listaUsuarioOnline.isEmpty()) {
			return false;
		}
		Usuario u = null;
		for (Map.Entry<String, Usuario> e : listaUsuarioOnline.entrySet()) {
			if (e.getKey().equals(login)) {
				u = e.getValue();
				if (u.getToken().equals(token)) {
					// Calendar calFechaInicial = Calendar.getInstance(); //
					// calcular tiempo limite de conexion
					// Calendar calFechaFinal = Calendar.getInstance();
					// calFechaInicial.setTime(u.getFechaHoraConexion());
					// calFechaFinal.setTime(new Date());
					return true;
				}
				return false;
			}
		}
		return false;
	}

	public synchronized static boolean usuarioIsOnline(final String login) {
		System.out.println(listaUsuarioOnline);
		if (listaUsuarioOnline.isEmpty()) {
			return false;
		}
		for (Map.Entry<String, Usuario> e : listaUsuarioOnline.entrySet()) {
			if (e.getKey().equals(login)) {
				return true;
			}
		}
		return false;
	}

	public synchronized static void usuarioDesconectado(final String login, final String token) {
		if (usuarioIsOnline(login)) {
			for (Map.Entry<String, Usuario> e : listaUsuarioOnline.entrySet()) {
				if (e.getKey().equals(login)) {
					listaTokenHabilitados.remove(token);
					listaUsuarioOnline.remove(login);
				}
			}
		}
	}

	public synchronized static boolean usuarioConectado(final String login, final Usuario usuario) {
		if (usuarioIsOnline(login)) {
			return false;
		}
		listaUsuarioOnline.put(login, usuario);
		return true;
	}

}
