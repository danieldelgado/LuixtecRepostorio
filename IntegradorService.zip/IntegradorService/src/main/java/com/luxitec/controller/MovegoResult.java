package com.luxitec.controller;

import com.luxitec.bean.LocalizacionBean;
import com.luxitec.bean.UsuarioBean;

public class MovegoResult {


	public final static String RESUTLADO_OK="1111111";
	public final static String RESUTLADO_NO_OK="0000000";

	public final static String LOCALIZACION_REGISTRADA="1864616";
	public final static String LOCALIZACION_NO_REGISTRADA="1864617";
	
	public final static String USUARIO_NO_ONLINE="1110012";

	private String mensaje;
    private String content;
	private String error;
	private UsuarioBean usuario;
	private LocalizacionBean localizacion;
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public UsuarioBean getUsuario() {
		return usuario;
	}
	public void setUsuario(UsuarioBean usuario) {
		this.usuario = usuario;
	}
	public LocalizacionBean getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(LocalizacionBean localizacion) {
		this.localizacion = localizacion;
	}
	
    
	
	

}