package com.luxitec.service;

import com.luxitec.bean.LocalizacionBean;
import com.luxitec.bean.UsuarioBean;
import com.luxitec.controller.MovegoResult;

public interface IntegradorService {

	MovegoResult registrarLocalizacion(UsuarioBean usuario, LocalizacionBean localizacion);

	UsuarioBean login(UsuarioBean u);

}
