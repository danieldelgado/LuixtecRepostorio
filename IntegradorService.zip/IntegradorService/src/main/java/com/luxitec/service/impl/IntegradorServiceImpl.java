package com.luxitec.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.luxitec.bean.LocalizacionBean;
import com.luxitec.bean.UsuarioBean;
import com.luxitec.controller.MovegoResult;
import com.luxitec.service.IntegradorService;

@Service("IntegradorService")
public class IntegradorServiceImpl  implements IntegradorService{

	private static List<UsuarioBean> listaUsuarioOnline = new ArrayList<>();
	
	@Override
	public MovegoResult registrarLocalizacion(UsuarioBean usuario, LocalizacionBean localizacion) {
		MovegoResult rt = new MovegoResult();
//		if(!usuarioOnline(usuario)){
//			rt.setError(MovegoResult.USUARIO_NO_ONLINE);
//			return rt;
//		}
		rt.setContent(MovegoResult.LOCALIZACION_REGISTRADA);
		usuario.setLocalizacion(localizacion);
		registrarLocalizacion(usuario);
		return rt;
	}

	private void registrarLocalizacion(UsuarioBean usuario) {
		System.out.println("impletar rest");
	}

	@Override
	public UsuarioBean login(UsuarioBean u) {
		listaUsuarioOnline.add(u);	
		return u;
	}

	private boolean usuarioOnline(UsuarioBean usuario) {
		if(listaUsuarioOnline.isEmpty()){
			return false;
		}
		for (UsuarioBean usuarioBean : listaUsuarioOnline) {
			if(usuarioBean.getId().equals(usuario.getId())){
				return true;
			}
		}
		
		
		return false;
	}
	
}
