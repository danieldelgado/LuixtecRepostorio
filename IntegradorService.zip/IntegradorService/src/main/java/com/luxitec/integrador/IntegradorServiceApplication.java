//package com.luxitec.integrador;
//
////import org.springframework.boot.SpringApplication;
////import org.springframework.boot.autoconfigure.SpringBootApplication;
////
////@SpringBootApplication
////public class IntegradorServiceApplication {
////
////	public static void main(String[] args) {
////		SpringApplication.run(IntegradorServiceApplication.class, args);
////	}
////}
