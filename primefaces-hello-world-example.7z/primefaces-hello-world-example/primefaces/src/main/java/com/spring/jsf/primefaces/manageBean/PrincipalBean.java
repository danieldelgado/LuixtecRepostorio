package com.spring.jsf.primefaces.manageBean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class PrincipalBean implements Serializable{

	
	
	@PostConstruct
	public void init() {
		System.out.println("PrincipalBean");
	}
	
	public String principal() {

		System.out.println("principal");
		
		return "principal";
	}

	public String inicio() {
		System.out.println("inicio");

	
		return "login";
	}


	
	
}
