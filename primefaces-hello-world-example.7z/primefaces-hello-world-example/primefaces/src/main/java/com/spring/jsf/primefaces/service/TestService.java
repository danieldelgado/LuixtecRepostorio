package com.spring.jsf.primefaces.service;

import org.springframework.stereotype.Component;

@Component
public class TestService {

	
	public String test() {
		System.out.println("testsetestestsetsetse");
		
		return "hola";
	}
}
