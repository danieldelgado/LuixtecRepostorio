package com.spring.jsf.primefaces.manageBean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.jsf.primefaces.service.TestService;

@ManagedBean
@ViewScoped
public class Pagina2 implements Serializable {

	@ManagedProperty("#{testService}")
	private TestService testService;

	
	private String value;
	
	@PostConstruct
	public void init() {
		System.out.println("testService2");
		System.out.println(testService);
	}
	
	public String register() {

		System.out.println("testService2");
		System.out.println(testService);
		
		return "pagina1";
	}
	

	public TestService getTestService() {
		return testService;
	}

	public void setTestService(TestService testService) {
		this.testService = testService;
	}
	
	

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
